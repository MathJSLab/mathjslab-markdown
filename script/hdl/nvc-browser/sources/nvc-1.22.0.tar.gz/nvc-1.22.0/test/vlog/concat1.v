module concat1;
  wire       x, y;
  wire [7:0] z;
  real       r1;
  reg        q;

  assign a1 = {x, y};   // OK
  assign a2 = {r1, x};  // Error
  assign {z[0], z[4]} = {x, y};   // OK
  assign {x, q} = 2'b11;  // OK (in System Verilog)
  assign a3 = {5{x}};   // OK
  assign a4 = {z{x}};   // Error

  parameter N = 4;
  assign a5 = {{N}{x}};   // OK
  assign a6 = {{N+1}{x}}; // OK

endmodule // concat1
