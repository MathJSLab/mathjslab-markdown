//
//  Copyright (C) 2025-2026 Nick Gasson
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

#ifndef _VHDL_PHASE_H
#define _VHDL_PHASE_H

#include "prim.h"

tree_t vhdl_component_instance(tree_t comp, tree_t inst, ident_t dotted);
tree_t vhdl_architecture_instance(tree_t arch, tree_t inst, ident_t dotted);
tree_t vhdl_config_instance(tree_t conf, tree_t bind, ident_t dotted);

void vhdl_package_instance(tree_t *roots, int nroots, ident_t dotted,
                           const ident_t *prefixes, int nprefix);
void vhdl_subprogram_instance(tree_t *roots, int nroots, ident_t dotted,
                              const ident_t *prefixes, int nprefix);

void vhdl_instance_fixup(tree_t inst, hash_t *map);

void vhdl_cover_block(tree_t block, cover_data_t *db, cover_scope_t *cs);
ident_t vhdl_scope_name(tree_t t, int nth);

#endif  // _VHDL_PHASE_H
