//
//  Copyright (C) 2023  Nick Gasson
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

#ifndef _TCL_SHELL_H
#define _TCL_SHELL_H

#include "prim.h"

typedef struct {
   void (*stdout_write)(const char *buf, size_t nchars, void *ctx);
   void (*stderr_write)(const char *buf, size_t nchars, void *ctx);
   void (*exit)(int status, void *ctx);
   void *context;
} shell_handler_t;

tcl_shell_t *shell_new(tree_t top, jit_t *jit, rt_model_t *m);
void shell_free(tcl_shell_t *sh);
bool shell_eval(tcl_shell_t *sh, const char *script, const char **result);
bool shell_do(tcl_shell_t *sh, const char *file);
void shell_interact(tcl_shell_t *sh);
void shell_reset(tcl_shell_t *sh);
void shell_set_handler(tcl_shell_t *sh, const shell_handler_t *h);
void shell_print_banner(tcl_shell_t *sh);

#endif  // _TCL_SHELL_H
