//
//  Copyright (C) 2023-2026  Nick Gasson
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

#include "util.h"
#include "array.h"
#include "common.h"
#include "diag.h"
#include "hash.h"
#include "ident.h"
#include "mir/mir-node.h"
#include "mir/mir-unit.h"
#include "printf.h"
#include "rt/rt.h"
#include "type.h"
#include "vlog/vlog-defs.h"
#include "vlog/vlog-node.h"
#include "vlog/vlog-number.h"
#include "vlog/vlog-phase.h"
#include "vlog/vlog-util.h"
#include "vpi/vpi-model.h"
#include "vpi/vpi_user.h"

#include <assert.h>
#include <inttypes.h>
#include <float.h>
#include <string.h>
#include <stdlib.h>

typedef struct _gen_stack gen_stack_t;

typedef struct {
   mir_type_t  type;
   mir_stamp_t stamp;
   unsigned    size;
   mir_type_t  signal;
   mir_type_t  unpacked;
   unsigned    elemsz;
} type_info_t;

typedef struct {
   mir_value_t obj;
   mir_value_t dst_offset;
   mir_value_t src_offset;
   mir_value_t count;
   mir_type_t  type;
   unsigned    size;
} vlog_select_t;

typedef struct {
   ident_t     name;
   mir_block_t test_bb;
   mir_block_t exit_bb;
} loop_info_t;

typedef struct {
   ident_t     name;
   mir_block_t exit_bb;
} block_info_t;

struct _gen_stack {
   gen_stack_t   *up;
   loop_info_t   *loop;
   block_info_t  *block;
   cover_scope_t *cscope;
};

typedef struct {
   mir_unit_t    *mu;
   mir_context_t *mir;
   ihash_t       *temps;
   mir_block_t    exit;
   bool           constfunc;
} vlog_gen_t;

static void vlog_lower_locals(vlog_gen_t *g, vlog_node_t v);

typedef enum {
   NOEDGE = 0x0,
   POSEDGE = 0x1,
   NEGEDGE = 0x2,
} vlog_edge_t;

#define PUSH_DEBUG_INFO(mu, v)                                          \
   __attribute__((cleanup(_mir_pop_debug_info), unused))                \
   const mir_saved_loc_t _old_loc =                                     \
      _mir_push_debug_info((mu), vlog_loc((v)));

static void vlog_lower_stmts(vlog_gen_t *g, vlog_node_t v, gen_stack_t *gs);
static mir_value_t vlog_lower_rvalue(vlog_gen_t *g, vlog_node_t v);
static mir_value_t vlog_lower_with_context(vlog_gen_t *g, vlog_node_t v,
                                           mir_type_t context);
static void vlog_lower_deferred(mir_unit_t *mu, object_t *obj);

static const type_info_t *vlog_type_info(vlog_gen_t *g, vlog_node_t v)
{
   const vlog_kind_t kind = vlog_kind(v);
   if (kind == V_TYPE_DECL || kind == V_ENUM_DECL)
      return vlog_type_info(g, vlog_type(v));

   type_info_t *ti = mir_get_priv(g->mu, v);
   if (ti != NULL)
      return ti;

   ti = mir_malloc(g->mu, sizeof(type_info_t));
   ti->stamp  = MIR_NULL_STAMP;
   ti->type   = MIR_NULL_TYPE;
   ti->signal = MIR_NULL_TYPE;
   ti->size   = 0;
   ti->elemsz = 0;

   mir_put_priv(g->mu, v, ti);

   switch (kind) {
   case V_DATA_TYPE:
      break;
   case V_STRUCT_DECL:
   case V_UNION_DECL:
      {
         assert(vlog_flags(v) & VLOG_F_PACKED);

         mir_type_t t_unpacked_logic = mir_int_type(g->mu, 0, 3);
         mir_type_t t_logic_signal = mir_signal_type(g->mu, t_unpacked_logic);

         const bool issigned = !!(vlog_flags(v) & VLOG_F_SIGNED);

         ti->size     = vlog_size(v);
         ti->type     = mir_vec4_type(g->mu, ti->size, issigned);
         ti->unpacked = t_unpacked_logic;
         ti->signal   = t_logic_signal;
         ti->elemsz   = 1;
         return ti;
      }
   case V_CLASS_DECL:
      {
         ident_t name = ident_prefix(vlog_ident2(v), vlog_ident(v), '.');
         ti->type = mir_context_type(g->mu, name);
         return ti;
      }
   default:
      CANNOT_HANDLE(v);
   }

   switch (vlog_subkind(v)) {
   case DT_REAL:
      ti->size   = 1;
      ti->type   = ti->unpacked = mir_real_type(g->mu, -DBL_MAX, DBL_MAX);
      ti->signal = mir_signal_type(g->mu, ti->type);
      ti->elemsz = sizeof(double);
      return ti;
   default:
      break;   // Vector type
   }

   mir_type_t t_unpacked_logic = mir_int_type(g->mu, 0, 3);
   mir_type_t t_logic_signal = mir_signal_type(g->mu, t_unpacked_logic);

   ti->unpacked = t_unpacked_logic;
   ti->signal   = t_logic_signal;
   ti->elemsz   = 1;

   const bool issigned = !!(vlog_flags(v) & VLOG_F_SIGNED);

   switch (vlog_subkind(v)) {
   case DT_LOGIC:
   case DT_IMPLICIT:
   case DT_INTEGER:
   case DT_TIME:
      ti->size = vlog_size(v);
      ti->type = mir_vec4_type(g->mu, ti->size, issigned);
      break;
   case DT_BIT:
   case DT_INT:
   case DT_SHORTINT:
   case DT_LONGINT:
   case DT_BYTE:
      ti->size = vlog_size(v);
      ti->type = mir_vec2_type(g->mu, ti->size, issigned);
      break;
   default:
      CANNOT_HANDLE(v);
   }

   return ti;
}

static unsigned vlog_packed_offset(vlog_node_t type, vlog_node_t member)
{
   assert(vlog_flags(type) & VLOG_F_PACKED);

   if (vlog_kind(type) == V_UNION_DECL)
      return 0;

   unsigned offset = 0;

   const int ndecls = vlog_decls(type);
   for (int i = 0; i < ndecls; i++) {
      vlog_node_t d = vlog_decl(type, i);
      if (d == member)
         return offset;

      offset += vlog_size(vlog_type(d));
   }

   should_not_reach_here();
}

static mir_value_t vlog_get_temp(vlog_gen_t *g, mir_type_t type)
{
   if (g->temps == NULL)
      g->temps = ihash_new(16);
   else {
      mir_value_t exist = { .bits = (uintptr_t)ihash_get(g->temps, type.bits) };
      if (!mir_is_null(exist))
         return exist;
   }

   mir_value_t temp = mir_add_var(g->mu, type, MIR_NULL_STAMP,
                                  ident_uniq("tmp"), MIR_VAR_TEMP);

   ihash_put(g->temps, type.bits, (void *)(uintptr_t)temp.bits);
   return temp;
}

static gen_stack_t vlog_push_block(gen_stack_t *gs, block_info_t *block)
{
   gen_stack_t this = {
      .block  = block,
      .cscope = gs->cscope,
      .up     = gs,
   };
   return this;
}

static mir_value_t vlog_lower_x(vlog_gen_t *g, mir_type_t type)
{
   assert(mir_get_class(g->mu, type) == MIR_TYPE_VEC4);

   if (mir_get_size(g->mu, type) <= 64)
      return mir_const_vec(g->mu, type, ~UINT64_C(0), ~UINT64_C(0));
   else {
      mir_type_t t_logic = mir_vec4_type(g->mu, 1, false);
      mir_value_t x = mir_const_vec(g->mu, t_logic, 1, 1);
      return mir_build_cast(g->mu, type, x);
   }
}

static mir_value_t vlog_lower_zero(vlog_gen_t *g, mir_type_t type)
{
   if (mir_get_class(g->mu, type) == MIR_TYPE_REAL)
      return mir_const_real(g->mu, type, 0.0);
   else if (mir_get_size(g->mu, type) <= 64)
      return mir_const_vec(g->mu, type, 0, 0);
   else {
      mir_type_t t_logic = mir_vec4_type(g->mu, 1, false);
      mir_value_t zero = mir_const_vec(g->mu, t_logic, 0, 0);
      return mir_build_cast(g->mu, type, zero);
   }
}

static mir_value_t vlog_lower_cast(vlog_gen_t *g, mir_type_t type,
                                   mir_value_t value)
{
   const mir_type_t value_type = mir_get_type(g->mu, value);
   const mir_class_t from = mir_get_class(g->mu, value_type);
   const mir_class_t to = mir_get_class(g->mu, type);
   const bool from_vec = from == MIR_TYPE_VEC4 || from == MIR_TYPE_VEC2;
   const bool to_vec = to == MIR_TYPE_VEC4 || to == MIR_TYPE_VEC2;

   if ((to == MIR_TYPE_REAL && from_vec) || (from == MIR_TYPE_REAL && to_vec)) {
      mir_type_t t_int64 = mir_int_type(g->mu, INT64_MIN, INT64_MAX);
      mir_value_t intg = vlog_lower_cast(g, t_int64, value);
      return mir_build_cast(g->mu, type, intg);
   }
   else if (from == MIR_TYPE_VEC4 && (to == MIR_TYPE_INT
                                      || to == MIR_TYPE_OFFSET)) {
      // TODO: how to handle X here
      const int size = mir_get_size(g->mu, value_type);
      const bool issigned = mir_get_signed(g->mu, value_type);
      mir_type_t t_vec2 = mir_vec2_type(g->mu, size, issigned);
      mir_value_t vec2 = mir_build_cast(g->mu, t_vec2, value);
      return mir_build_cast(g->mu, type, vec2);
   }
   else
      return mir_build_cast(g->mu, type, value);
}

static mir_value_t vlog_lower_test(vlog_gen_t *g, mir_value_t value)
{
   if (mir_is_vector(g->mu, value))
      return mir_build_test(g->mu, value);

   mir_type_t type = mir_get_type(g->mu, value);
   if (mir_equals(type, mir_bool_type(g->mu)))
      return value;
   else {
      mir_value_t zero = vlog_lower_zero(g, type);
      mir_value_t cmp = mir_build_cmp(g->mu, MIR_CMP_EQ, value, zero);
      return mir_build_not(g->mu, cmp);
   }
}

static mir_value_t vlog_lower_array_off(vlog_gen_t *g, vlog_node_t r,
                                        mir_value_t index)
{
   mir_type_t t_offset = mir_offset_type(g->mu);
   mir_value_t cast = vlog_lower_cast(g, t_offset, index);

   assert(vlog_kind(r) == V_DIMENSION);

   int64_t lconst, rconst;
   vlog_bounds(r, &lconst, &rconst);

   mir_value_t left = mir_const(g->mu, t_offset, lconst);

   if (lconst < rconst)
      return mir_build_sub(g->mu, t_offset, cast, left);
   else
      return mir_build_sub(g->mu, t_offset, left, cast);
}

static mir_value_t vlog_lower_offset_min(vlog_gen_t *g, mir_value_t left,
                                         mir_value_t right)
{
   mir_type_t t_offset = mir_offset_type(g->mu);
   mir_value_t cmp = mir_build_cmp(g->mu, MIR_CMP_LT, left, right);
   return mir_build_select(g->mu, t_offset, cmp, left, right);
}

static mir_value_t vlog_lower_offset_max(vlog_gen_t *g, mir_value_t left,
                                         mir_value_t right)
{
   mir_type_t t_offset = mir_offset_type(g->mu);
   mir_value_t cmp = mir_build_cmp(g->mu, MIR_CMP_GT, left, right);
   return mir_build_select(g->mu, t_offset, cmp, left, right);
}

static vlog_select_t vlog_lower_select(vlog_gen_t *g, vlog_node_t v)
{
   PUSH_DEBUG_INFO(g->mu, v);

   switch (vlog_kind(v)) {
   case V_REF:
      {
         mir_type_t t_offset = mir_offset_type(g->mu);
         mir_value_t zero = mir_const(g->mu, t_offset, 0);

         vlog_node_t decl = vlog_ref(v);
         switch (vlog_kind(decl)) {
         case V_PORT_DECL:
            decl = vlog_ref(decl);
            break;
         case V_PARAM_DECL:
         case V_LOCALPARAM:
         case V_ENUM_NAME:
            {
               const type_info_t *ti = vlog_type_info(g, vlog_type(decl));

               mir_value_t value = vlog_lower_rvalue(g, vlog_value(decl));
               mir_value_t cast = vlog_lower_cast(g, ti->type, value);

               vlog_select_t result = {
                  .obj        = cast,
                  .type       = ti->type,
                  .dst_offset = zero,
                  .count      = mir_const(g->mu, t_offset, ti->size),
                  .src_offset = zero,
                  .size       = ti->size,
               };
               return result;
            }
         default:
            break;
         }

         int hops;
         mir_value_t var = mir_search_object(g->mu, decl, &hops);
         if (mir_is_null(var)) {
            mir_dump(g->mu);
            fatal_trace("missing variable for %pK %pi", decl, vlog_ident(decl));
         }

         mir_value_t ptr = var;
         if (hops > 0)
            ptr = mir_build_var_upref(g->mu, hops, var.id);

         mir_value_t nets = ptr;
         if (mir_points_to(g->mu, ptr, MIR_TYPE_SIGNAL))
            nets = mir_build_load(g->mu, ptr);

         const type_info_t *ti = vlog_type_info(g, vlog_type(decl));

         vlog_select_t result = {
            .obj        = nets,
            .type       = ti->type,
            .dst_offset = zero,
            .count      = mir_const(g->mu, t_offset, ti->size),
            .src_offset = zero,
            .size       = ti->size,
         };
         return result;
      }

   case V_HIER_REF:
      {
         if (!vlog_has_ref(v))
            fatal_at(vlog_loc(v), "unbound hierarchical reference");

         vlog_node_t decl = vlog_ref(v);
         const type_info_t *ti = vlog_type_info(g, vlog_type(decl));

         mir_value_t locus = mir_build_debug_locus(g->mu, vlog_to_object(v));
         ident_t scope = mir_get_parent(g->mu);

         mir_value_t ptr = mir_build_bind_external(g->mu, locus, scope,
                                                   ti->signal, ti->stamp,
                                                   NULL, 0);

         mir_type_t t_offset = mir_offset_type(g->mu);
         mir_value_t zero = mir_const(g->mu, t_offset, 0);

         vlog_select_t result = {
            .obj        = mir_build_load(g->mu, ptr),
            .type       = ti->type,
            .dst_offset = zero,
            .count      = mir_const(g->mu, t_offset, ti->size),
            .src_offset = zero,
            .size       = ti->size,
         };
         return result;
      }
   case V_BIT_SELECT:
      {
         vlog_node_t value = vlog_value(v);
         assert(vlog_kind(value) == V_REF);

         vlog_select_t prefix = vlog_lower_select(g, value);

         vlog_node_t decl = vlog_ref(value);
         const int nunpacked =
            vlog_kind(decl) == V_LOCAL_DECL ? vlog_ranges(decl) : 0;
         const int nparams = vlog_params(v);

         const bool unpacked_var =
            nunpacked > 0 && (mir_points_to_vector(g->mu, prefix.obj));

         mir_type_t t_offset = mir_offset_type(g->mu);
         mir_value_t zero = mir_const(g->mu, t_offset, 0);
         mir_value_t array_off = zero, bit_off = zero;

         mir_value_t in_range =
            mir_build_cmp(g->mu, MIR_CMP_NEQ, prefix.count, zero);

         unsigned elems = vlog_size(decl);
         unsigned size = unpacked_var
            ? mir_get_size(g->mu, prefix.type)
            : elems * mir_get_size(g->mu, prefix.type);

         for (int i = 0; i < nparams; i++) {
            vlog_node_t dim = vlog_get_dim(value, i);

            const unsigned dim_size = vlog_size(dim);
            const bool unpacked_dim =
               unpacked_var && vlog_subkind(dim) == V_DIM_UNPACKED;

            if (unpacked_dim) {
               assert(elems % dim_size == 0);
               elems /= dim_size;
            }
            else {
               assert(size % dim_size == 0);
               size /= dim_size;
            }

            mir_value_t index = vlog_lower_rvalue(g, vlog_param(v, i));
            mir_value_t this_off = vlog_lower_array_off(g, dim, index);
            mir_value_t known = mir_build_defined(g->mu, index);

            mir_value_t count = mir_const(g->mu, t_offset, dim_size);
            mir_value_t cmp_low =
               mir_build_cmp(g->mu, MIR_CMP_GEQ, this_off, zero);
            mir_value_t cmp_high =
               mir_build_cmp(g->mu, MIR_CMP_LT, this_off, count);
            mir_value_t this_in_range = mir_build_and(g->mu, cmp_low, cmp_high);
            this_in_range = mir_build_and(g->mu, known, this_in_range);

            const unsigned scale_by = unpacked_dim ? elems : size;
            if (scale_by != 1) {
               mir_value_t scale = mir_const(g->mu, t_offset, scale_by);
               this_off = mir_build_mul(g->mu, t_offset, this_off, scale);
            }

            in_range = mir_build_and(g->mu, in_range, this_in_range);
            if (unpacked_dim)
               array_off = mir_build_add(g->mu, t_offset, array_off, this_off);
            else
               bit_off = mir_build_add(g->mu, t_offset, bit_off, this_off);
         }

         mir_value_t count = mir_build_select(g->mu, t_offset, in_range,
                                              mir_const(g->mu, t_offset, size),
                                              zero);

         mir_value_t obj = prefix.obj;
         if (unpacked_var)
            obj = mir_build_array_ref(g->mu, prefix.obj, array_off);

         vlog_select_t result = {
            .obj        = obj,
            .dst_offset = bit_off,
            .count      = count,
            .src_offset = mir_const(g->mu, t_offset, 0),
            .type       = mir_vec4_type(g->mu, size, false),
            .size       = size,
         };
         return result;
      }
   case V_PART_SELECT:
      {
         vlog_node_t value = vlog_value(v);
         vlog_select_t prefix = vlog_lower_select(g, value);

         const vlog_range_kind_t kind = vlog_subkind(v);

         vlog_node_t dim = vlog_get_dim(value, 0);

         mir_value_t index = vlog_lower_rvalue(g, vlog_left(v));
         mir_value_t base = vlog_lower_array_off(g, dim, index);

         mir_value_t off = base;
         const unsigned nelems = vlog_size(v);
         if (kind != V_RANGE_CONST) {
            const bool is_up = vlog_is_up(dim);
            const bool same_dir = (kind == V_RANGE_POS && is_up)
               || (kind == V_RANGE_NEG && !is_up);

            if (!same_dir) {
               mir_type_t t_offset = mir_offset_type(g->mu);
               mir_value_t adj = mir_const(g->mu, t_offset, nelems - 1);
               off = mir_build_sub(g->mu, t_offset, base, adj);
            }
         }

         mir_type_t t_offset = mir_offset_type(g->mu);

         const unsigned dim_size = vlog_size(dim);
         assert(prefix.size % dim_size == 0);

         const unsigned stride = prefix.size / dim_size;
         const unsigned size = nelems * stride;

         if (stride != 1) {
            mir_value_t scale = mir_const(g->mu, t_offset, stride);
            off = mir_build_mul(g->mu, t_offset, off, scale);
         }

         mir_value_t zero = mir_const(g->mu, t_offset, 0);
         mir_value_t count = mir_const(g->mu, t_offset, size);
         mir_value_t high = mir_build_add(g->mu, t_offset, off, count);

         mir_value_t prefix_valid_high =
            mir_build_add(g->mu, t_offset, prefix.src_offset, prefix.count);

         mir_value_t valid_start =
            vlog_lower_offset_max(g, off, prefix.src_offset);
         mir_value_t valid_stop =
            vlog_lower_offset_min(g, high, prefix_valid_high);
         mir_value_t raw_count =
            mir_build_sub(g->mu, t_offset, valid_stop, valid_start);
         mir_value_t valid_count = vlog_lower_offset_max(g, raw_count, zero);

         if (kind != V_RANGE_CONST) {
            mir_value_t known = mir_build_defined(g->mu, index);
            valid_count = mir_build_select(g->mu, t_offset, known, valid_count,
                                           zero);
         }

         mir_value_t value_offset =
            mir_build_sub(g->mu, t_offset, valid_start, off);

         mir_value_t dst_offset =
            mir_build_add(g->mu, t_offset, prefix.dst_offset,
                          mir_build_sub(g->mu, t_offset,
                                        valid_start, prefix.src_offset));

         vlog_select_t result = {
            .obj        = prefix.obj,
            .dst_offset = dst_offset,
            .count      = valid_count,
            .src_offset = value_offset,
            .type       = mir_vec4_type(g->mu, size, false),
            .size       = size,
         };
         return result;
      }
   case V_MEMBER_REF:
      {
         vlog_select_t prefix = vlog_lower_select(g, vlog_value(v));
         vlog_node_t decl = vlog_ref(v);
         const type_info_t *ti = vlog_type_info(g, vlog_type(decl));

         if (mir_points_to(g->mu, prefix.obj, MIR_TYPE_CONTEXT)) {
            mir_value_t context = mir_build_load(g->mu, prefix.obj);
            mir_value_t link = mir_build_link_var(g->mu, context,
                                                  vlog_ident(v), ti->type);
            mir_type_t t_offset = mir_offset_type(g->mu);
            mir_value_t zero = mir_const(g->mu, t_offset, 0);

            vlog_select_t result = {
               .obj        = link,
               .dst_offset = zero,
               .count      = mir_const(g->mu, t_offset, ti->size),
               .src_offset = zero,
               .type       = ti->type,
               .size       = ti->size,
            };
            return result;
         }

         vlog_node_t type = vlog_get_type(vlog_value(v));
         assert(vlog_flags(type) & VLOG_F_PACKED);

         mir_type_t t_offset = mir_offset_type(g->mu);
         mir_value_t offset =
            mir_const(g->mu, t_offset, vlog_packed_offset(type, decl));
         mir_value_t dst_offset =
            mir_build_add(g->mu, t_offset, prefix.dst_offset, offset);

         vlog_select_t result = {
            .obj        = prefix.obj,
            .dst_offset = dst_offset,
            .count      = mir_const(g->mu, t_offset, ti->size),
            .src_offset = mir_const(g->mu, t_offset, 0),
            .type       = ti->type,
            .size       = ti->size,
         };
         return result;
      }
   default:
      CANNOT_HANDLE(v);
   }
}

static unsigned vlog_count_lvalues(vlog_node_t v)
{
   if (vlog_kind(v) != V_CONCAT)
      return 1;

   unsigned count = 0;
   const int nparams = vlog_params(v);
   for (int i = 0; i < nparams; i++)
      count += vlog_count_lvalues(vlog_param(v, i));

   return count;
}

static void vlog_lower_lvalues(vlog_gen_t *g, vlog_node_t v,
                               vlog_select_t *lvalues, vlog_node_t *nodes,
                               unsigned *index)
{
   if (vlog_kind(v) == V_CONCAT) {
      const int nparams = vlog_params(v);
      for (int i = 0; i < nparams; i++)
         vlog_lower_lvalues(g, vlog_param(v, i), lvalues, nodes, index);
   }
   else {
      lvalues[*index] = vlog_lower_select(g, v);
      if (nodes != NULL)
         nodes[*index] = v;
      (*index)++;
   }
}

static void vlog_assign_variable(vlog_gen_t *g, vlog_node_t target,
                                 mir_value_t value, vlog_node_t rhs)
{
   unsigned nlvalues = 1, targetsz = 0;
   mir_type_t context;
   vlog_select_t lvalue1, *lvalues = &lvalue1;
   vlog_node_t node1, *nodes = &node1;
   if (vlog_kind(target) == V_CONCAT) {
      nlvalues = vlog_count_lvalues(target);
      lvalues = xmalloc_array(nlvalues, sizeof(vlog_select_t));
      nodes = xmalloc_array(nlvalues, sizeof(vlog_node_t));

      unsigned index = 0;
      vlog_lower_lvalues(g, target, lvalues, nodes, &index);
      assert(index == nlvalues);

      for (int i = 0; i < nlvalues; i++)
         targetsz += lvalues[i].size;

      context = mir_vec4_type(g->mu, targetsz, false);
   }
   else {
      lvalue1 = vlog_lower_select(g, target);
      node1 = target;
      targetsz = lvalue1.size;
      context = lvalue1.type;
   }

   if (mir_is_null(value))
      value = vlog_lower_with_context(g, rhs, context);

   if (mir_is(g->mu, value, MIR_TYPE_UARRAY)) {
      mir_build_store(g->mu, lvalues[0].obj, value);
      return;
   }

   mir_value_t cast = vlog_lower_cast(g, context, value);

   if (mir_is_signal(g->mu, lvalues[0].obj)) {
      mir_value_t unpacked;
      if (mir_is_vector(g->mu, cast)) {
         mir_value_t tmp = MIR_NULL_VALUE;
         if (targetsz > 1) {
            mir_type_t t_elem = mir_logic_type(g->mu);
            mir_type_t t_array = mir_carray_type(g->mu, targetsz, t_elem);
            tmp = vlog_get_temp(g, t_array);
         }

         unpacked = mir_build_unpack(g->mu, cast, 0, tmp);
      }
      else
         unpacked = cast;

      mir_type_t t_offset = mir_offset_type(g->mu);

      for (int i = 0, offset = 0; i < nlvalues;
           offset += lvalues[i].size, i++) {
         mir_value_t nets = mir_build_array_ref(g->mu, lvalues[i].obj,
                                                lvalues[i].dst_offset);

         mir_block_t merge_bb = MIR_NULL_BLOCK;

         int64_t count_const;
         if (mir_get_const(g->mu, lvalues[i].count, &count_const)) {
            if (count_const == 0) {
               mir_comment(g->mu, "Out-of-range assignment");
               continue;
            }
         }
         else {
            mir_block_t guarded_bb = mir_add_block(g->mu);
            merge_bb = mir_add_block(g->mu);

            mir_value_t overlaps = mir_build_cmp(g->mu, MIR_CMP_NEQ,
                                                 lvalues[i].count,
                                                 mir_const(g->mu, t_offset, 0));
            mir_build_cond(g->mu, overlaps, guarded_bb, merge_bb);

            mir_set_cursor(g->mu, guarded_bb, MIR_APPEND);
         }

         mir_value_t pos = mir_build_add(g->mu, t_offset,
                                         mir_const(g->mu, t_offset, offset),
                                         lvalues[i].src_offset);
         mir_value_t src = mir_build_array_ref(g->mu, unpacked, pos);

         mir_build_deposit_signal(g->mu, nets, lvalues[i].count, src);

         if (!mir_is_null(merge_bb)) {
            mir_build_jump(g->mu, merge_bb);
            mir_set_cursor(g->mu, merge_bb, MIR_APPEND);
         }
      }
   }
   else if (mir_points_to_vector(g->mu, lvalues[0].obj)) {
      mir_type_t t_offset = mir_offset_type(g->mu);

      for (int i = 0, offset = 0; i < nlvalues;
           offset += lvalues[i].size, i++) {
         mir_block_t merge_bb = MIR_NULL_BLOCK;

         mir_type_t part_type;
         int64_t count_const;
         if (mir_get_const(g->mu, lvalues[i].count, &count_const)) {
            if (count_const == 0) {
               mir_comment(g->mu, "Out-of-range assignment");
               continue;
            }

            part_type = mir_vector_slice(g->mu, lvalues[i].type, count_const);
         }
         else {
            mir_block_t guarded_bb = mir_add_block(g->mu);
            merge_bb = mir_add_block(g->mu);

            mir_value_t overlaps = mir_build_cmp(g->mu, MIR_CMP_NEQ,
                                                 lvalues[i].count,
                                                 mir_const(g->mu, t_offset, 0));
            mir_build_cond(g->mu, overlaps, guarded_bb, merge_bb);

            mir_set_cursor(g->mu, guarded_bb, MIR_APPEND);

            part_type = lvalues[i].type;
         }

         mir_value_t pos = mir_build_add(g->mu, t_offset,
                                         mir_const(g->mu, t_offset, offset),
                                         lvalues[i].src_offset);
         mir_value_t part = mir_build_extract(g->mu, part_type, cast, pos);

         switch (vlog_kind(nodes[i])) {
         case V_REF:
         case V_MEMBER_REF:
            mir_build_store(g->mu, lvalues[i].obj, part);
            break;
         default:
            {
               mir_value_t cur = mir_build_load(g->mu, lvalues[i].obj);
               mir_value_t ins =
                  mir_build_insert(g->mu, part, cur, lvalues[i].dst_offset);
               mir_build_store(g->mu, lvalues[i].obj, ins);
            }
            break;
         }

         if (!mir_is_null(merge_bb)) {
            mir_build_jump(g->mu, merge_bb);
            mir_set_cursor(g->mu, merge_bb, MIR_APPEND);
         }
      }
   }
   else {
      assert(nlvalues == 1);
      mir_build_store(g->mu, lvalues[0].obj, cast);
   }
}

static mir_value_t vlog_lower_unary(vlog_gen_t *g, vlog_node_t v,
                                    mir_type_t context)
{
   const vlog_unary_t op = vlog_subkind(v);
   const bool propagate_context =
      op == V_UNARY_BITNEG || op == V_UNARY_NEG || op == V_UNARY_IDENTITY;

   mir_value_t input;
   if (propagate_context)
      input = vlog_lower_with_context(g, vlog_value(v), context);
   else
      input = vlog_lower_rvalue(g, vlog_value(v));

   if (op == V_UNARY_IDENTITY)
      return input;

   if (mir_is_vector(g->mu, input)) {
      bool negate = false;
      mir_vec_op_t mop;
      switch (op) {
      case V_UNARY_BITNEG: mop = MIR_VEC_BIT_NOT; break;
      case V_UNARY_NOT:    mop = MIR_VEC_LOG_NOT; break;
      case V_UNARY_NEG:    mop = MIR_VEC_SUB; break;
      case V_UNARY_OR:     mop = MIR_VEC_BIT_OR; break;
      case V_UNARY_XOR:    mop = MIR_VEC_BIT_XOR; break;
      case V_UNARY_AND:    mop = MIR_VEC_BIT_AND; break;
      case V_UNARY_NAND:   mop = MIR_VEC_BIT_AND; negate = true; break;
      case V_UNARY_NOR:    mop = MIR_VEC_BIT_OR; negate = true; break;
      case V_UNARY_XNOR:   mop = MIR_VEC_BIT_XOR; negate = true; break;
      default:
         CANNOT_HANDLE(v);
      }

      mir_type_t itype = mir_get_type(g->mu, input);

      const mir_class_t class = mir_get_class(g->mu, itype);
      const bool is_signed = mir_get_signed(g->mu, itype);

      int size = mir_get_size(g->mu, itype);
      if (propagate_context && !mir_is_null(context))
         size = MAX(mir_get_size(g->mu, context), size);

      mir_type_t type;
      if (class == MIR_TYPE_VEC4)
         type = mir_vec4_type(g->mu, size, is_signed);
      else
         type = mir_vec2_type(g->mu, size, is_signed);

      mir_value_t cast = mir_build_cast(g->mu, type, input);
      mir_value_t result = mir_build_unary(g->mu, mop, type, cast);
      if (!negate)
         return result;

      mir_type_t otype = mir_get_type(g->mu, result);
      assert(mir_get_size(g->mu, otype) == 1);

      return mir_build_unary(g->mu, MIR_VEC_BIT_NOT, otype, result);
   }
   else {
      mir_type_t type = mir_get_type(g->mu, input);

      switch (vlog_subkind(v)) {
      case V_UNARY_NEG:
         return mir_build_neg(g->mu, type, input);
      case V_UNARY_NOT:
         return mir_build_not(g->mu, vlog_lower_test(g, input));
      default:
         CANNOT_HANDLE(v);
      }
   }
}

static bool vlog_has_side_effects(vlog_node_t v)
{
   switch (vlog_kind(v)) {
   case V_REF:
   case V_BIT_SELECT:
   case V_PART_SELECT:
   case V_NUMBER:
      return false;
   case V_UNARY:
      return vlog_has_side_effects(vlog_value(v));
   case V_BINARY:
      return vlog_has_side_effects(vlog_left(v))
         || vlog_has_side_effects(vlog_right(v));
   default:
      return true;
   }
}

static mir_value_t vlog_cast_unsigned(vlog_gen_t *g, mir_value_t value)
{
   if (!mir_is_vector(g->mu, value))
      return value;

   mir_type_t type = mir_get_type(g->mu, value);
   if (!mir_get_signed(g->mu, type))
      return value;

   mir_type_t utype = mir_vec4_type(g->mu, mir_get_size(g->mu, type), false);
   return mir_build_cast(g->mu, utype, value);
}

static mir_value_t vlog_widen_vector(vlog_gen_t *g, mir_value_t value,
                                     mir_type_t context)
{
   if (mir_is_null(context))
      return value;
   else if (!mir_is_vector(g->mu, value))
      return value;

   mir_class_t class = mir_get_class(g->mu, context);
   if (class != MIR_TYPE_VEC2 && class != MIR_TYPE_VEC4)
      return value;

   mir_type_t type = mir_get_type(g->mu, value);

   const int size = mir_get_size(g->mu, context);
   if (size <= mir_get_size(g->mu, type))
      return value;

   mir_comment(g->mu, "Widen to %d from context", size);

   const bool issigned = mir_get_signed(g->mu, type);

   mir_type_t wide;
   if (class == MIR_TYPE_VEC2)
      wide = mir_vec2_type(g->mu, size, issigned);
   else
      wide = mir_vec4_type(g->mu, size, issigned);

   return mir_build_cast(g->mu, wide, value);
}

static mir_value_t vlog_lower_vector_shift(vlog_gen_t *g, vlog_binary_t binop,
                                            mir_value_t left, mir_value_t right,
                                            mir_type_t context)
{
   mir_type_t ltype = mir_get_type(g->mu, left);
   mir_type_t rtype = mir_get_type(g->mu, right);

   const mir_class_t lclass = mir_get_class(g->mu, ltype);
   const mir_class_t rclass = mir_get_class(g->mu, rtype);

   const int lsize = mir_get_size(g->mu, ltype);
   const int rsize = mir_get_size(g->mu, rtype);

   const bool lsigned = mir_get_signed(g->mu, ltype);

   mir_type_t type;
   if (lclass == MIR_TYPE_VEC4 || rclass == MIR_TYPE_VEC4)
      type = mir_vec4_type(g->mu, lsize, lsigned);
   else
      type = mir_vec2_type(g->mu, lsize, lsigned);

   mir_type_t urtype = mir_vec4_type(g->mu, rsize, false);
   mir_value_t zext = mir_build_cast(g->mu, urtype, right);

   if (rsize > lsize) {
      // Handle large shifts that cannot be represented in LHS type
      mir_type_t t_uint32 = mir_vec2_type(g->mu, 32, false);
      mir_value_t limit = mir_const_vec(g->mu, t_uint32, lsize, 0);
      mir_value_t cast = mir_build_cast(g->mu, urtype, limit);
      mir_value_t geq = mir_build_binary(g->mu, MIR_VEC_GEQ, urtype,
                                         zext, cast);
      zext = mir_build_select(g->mu, urtype, vlog_lower_test(g, geq),
                              cast, zext);
   }

   mir_value_t lcast = mir_build_cast(g->mu, type, left);
   mir_value_t rcast = mir_build_cast(g->mu, type, zext);

   mir_vec_op_t mop;
   switch (binop) {
   case V_BINARY_SHIFT_LL:
   case V_BINARY_SHIFT_LA: mop = MIR_VEC_SLL; break;
   case V_BINARY_SHIFT_RL: mop = MIR_VEC_SRL; break;
   case V_BINARY_SHIFT_RA: mop = lsigned ? MIR_VEC_SRA : MIR_VEC_SRL; break;
   case V_BINARY_EXP:      mop = MIR_VEC_EXP; break;
   default:                should_not_reach_here();
   }

   return mir_build_binary(g->mu, mop, type, lcast, rcast);
}

static mir_value_t vlog_lower_vector_binary(vlog_gen_t *g, vlog_binary_t binop,
                                            mir_value_t left, mir_value_t right,
                                            mir_type_t context)
{
   mir_type_t ltype = mir_get_type(g->mu, left);
   mir_type_t rtype = mir_get_type(g->mu, right);

   const mir_class_t lclass = mir_get_class(g->mu, ltype);
   const mir_class_t rclass = mir_get_class(g->mu, rtype);

   const int lsize = mir_get_size(g->mu, ltype);
   const int rsize = mir_get_size(g->mu, rtype);

   const bool is_exp = binop == V_BINARY_EXP;

   const bool lsigned = mir_get_signed(g->mu, ltype);
   const bool rsigned = mir_get_signed(g->mu, rtype);

   const bool is_signed = lsigned && (is_exp || rsigned);

   int size = MAX(lsize, rsize);
   if (!mir_is_null(context)) {
      mir_class_t class = mir_get_class(g->mu, context);
      if (class == MIR_TYPE_VEC2 || class == MIR_TYPE_VEC4)
         size = MAX(mir_get_size(g->mu, context), size);
   }

   mir_type_t type;
   if (lclass == MIR_TYPE_VEC4 || rclass == MIR_TYPE_VEC4)
      type = mir_vec4_type(g->mu, size, is_signed);
   else
      type = mir_vec2_type(g->mu, size, is_signed);

   const bool unsigned_numeric =
      binop == V_BINARY_PLUS || binop == V_BINARY_MINUS
      || binop == V_BINARY_TIMES || binop == V_BINARY_DIVIDE
      || binop == V_BINARY_MOD
      || binop == V_BINARY_LT || binop == V_BINARY_LEQ
      || binop == V_BINARY_GT || binop == V_BINARY_GEQ
      || binop == V_BINARY_LOG_EQ || binop == V_BINARY_LOG_NEQ;

   if (unsigned_numeric && !is_signed) {
      // Mixed signedness binary expressions are evaluated as unsigned, so
      // signed operands must not be sign-extended when resized
      left = vlog_cast_unsigned(g, left);
      right = vlog_cast_unsigned(g, right);
   }

   mir_value_t lcast = mir_build_cast(g->mu, type, left);
   mir_value_t rcast = mir_build_cast(g->mu, type, right);

   bool negate = false;
   mir_vec_op_t mop;
   switch (binop) {
   case V_BINARY_AND:      mop = MIR_VEC_BIT_AND; break;
   case V_BINARY_OR:       mop = MIR_VEC_BIT_OR; break;
   case V_BINARY_XOR:      mop = MIR_VEC_BIT_XOR; break;
   case V_BINARY_XNOR:     mop = MIR_VEC_BIT_XOR; negate = true; break;
   case V_BINARY_NAND:     mop = MIR_VEC_BIT_AND; negate = true; break;
   case V_BINARY_NOR:      mop = MIR_VEC_BIT_OR; negate = true; break;
   case V_BINARY_LOG_AND:  mop = MIR_VEC_LOG_AND; break;
   case V_BINARY_LOG_OR:   mop = MIR_VEC_LOG_OR; break;
   case V_BINARY_LT:       mop = MIR_VEC_LT; break;
   case V_BINARY_LEQ:      mop = MIR_VEC_LEQ; break;
   case V_BINARY_GT:       mop = MIR_VEC_GT; break;
   case V_BINARY_GEQ:      mop = MIR_VEC_GEQ; break;
   case V_BINARY_LOG_EQ:   mop = MIR_VEC_LOG_EQ; break;
   case V_BINARY_LOG_NEQ:  mop = MIR_VEC_LOG_NEQ; break;
   case V_BINARY_CASE_EQ:  mop = MIR_VEC_CASE_EQ; break;
   case V_BINARY_CASE_NEQ: mop = MIR_VEC_CASE_NEQ; break;
   case V_BINARY_PLUS:     mop = MIR_VEC_ADD; break;
   case V_BINARY_MINUS:    mop = MIR_VEC_SUB; break;
   case V_BINARY_TIMES:    mop = MIR_VEC_MUL; break;
   case V_BINARY_DIVIDE:   mop = MIR_VEC_DIV; break;
   case V_BINARY_MOD:      mop = MIR_VEC_MOD; break;
   case V_BINARY_EXP:      mop = MIR_VEC_EXP; break;
   default:                should_not_reach_here();
   }

   mir_value_t result = mir_build_binary(g->mu, mop, type, lcast, rcast);
   if (negate) {
      mir_type_t otype = mir_get_type(g->mu, result);
      return mir_build_unary(g->mu, MIR_VEC_BIT_NOT, otype, result);
   }

   return result;
}

static mir_value_t vlog_lower_binary(vlog_gen_t *g, vlog_node_t v,
                                     mir_type_t context)
{
   const vlog_binary_t op = vlog_subkind(v);
   const bool propagate_context =
      op == V_BINARY_AND || op == V_BINARY_OR || op == V_BINARY_XOR
      || op == V_BINARY_XNOR || op == V_BINARY_NAND || op == V_BINARY_NOR
      || op == V_BINARY_PLUS || op == V_BINARY_MINUS || op == V_BINARY_TIMES
      || op == V_BINARY_DIVIDE || op == V_BINARY_MOD || op == V_BINARY_EXP;
   const bool rhs_self_determined =
      op == V_BINARY_SHIFT_LA || op == V_BINARY_SHIFT_LL
      || op == V_BINARY_SHIFT_RA || op == V_BINARY_SHIFT_RL;

   vlog_node_t lhs_expr = vlog_left(v), rhs_expr = vlog_right(v);

   mir_type_t type = context;
   if (!rhs_self_determined) {
      int size = MAX(vlog_width(lhs_expr), vlog_width(rhs_expr));
      if (propagate_context && !mir_is_null(context)) {
         mir_class_t class = mir_get_class(g->mu, context);
         if (class == MIR_TYPE_VEC2 || class == MIR_TYPE_VEC4)
            size = MAX(size, mir_get_size(g->mu, context));
      }

      type = mir_vec4_type(g->mu, size, false);
   }

   mir_value_t left = vlog_lower_with_context(g, lhs_expr, type);

   // For short-circuiting operators check if the RHS can have side effects
   mir_block_t guard_bb = MIR_NULL_BLOCK, skip_bb = MIR_NULL_BLOCK;
   mir_value_t var = MIR_NULL_VALUE;
   const bool is_short_circuit =
      op == V_BINARY_LOG_AND || op == V_BINARY_LOG_OR;

   if (is_short_circuit && vlog_has_side_effects(rhs_expr)) {
      guard_bb = mir_add_block(g->mu);
      skip_bb = mir_add_block(g->mu);

      // TODO: use a phi
      mir_type_t t_logic = mir_vec4_type(g->mu, 1, false);
      var = mir_add_var(g->mu, t_logic, MIR_NULL_STAMP,
                        ident_uniq("shortcircuit"), MIR_VAR_TEMP);

      mir_value_t def = mir_const_vec(g->mu, t_logic, op == V_BINARY_LOG_OR, 0);
      mir_build_store(g->mu, var, def);

      mir_value_t test = vlog_lower_test(g, left);
      if (op == V_BINARY_LOG_OR)
         mir_build_cond(g->mu, test, skip_bb, guard_bb);
      else
         mir_build_cond(g->mu, test, guard_bb, skip_bb);

      mir_set_cursor(g->mu, guard_bb, MIR_APPEND);
   }

   mir_value_t right;
   if (rhs_self_determined)
      right = vlog_lower_rvalue(g, rhs_expr);
   else
      right = vlog_lower_with_context(g, rhs_expr, type);

   mir_value_t result;
   if (mir_is_vector(g->mu, left) && mir_is_vector(g->mu, right)) {
      switch (op) {
      case V_BINARY_SHIFT_LL:
      case V_BINARY_SHIFT_LA:
      case V_BINARY_SHIFT_RL:
      case V_BINARY_SHIFT_RA:
         result = vlog_lower_vector_shift(g, op, left, right, context);
         break;
      default:
         result = vlog_lower_vector_binary(g, op, left, right, context);
         break;
      }
   }
   else {
      mir_type_t ltype = mir_get_type(g->mu, left);
      mir_type_t rtype = mir_get_type(g->mu, right);

      if (mir_get_class(g->mu, ltype) == MIR_TYPE_REAL)
         right = vlog_lower_cast(g, (rtype = ltype), right);
      else if (mir_get_class(g->mu, rtype) == MIR_TYPE_REAL)
         left = vlog_lower_cast(g, (ltype = rtype), left);

      switch (op) {
      case V_BINARY_LOG_EQ:
      case V_BINARY_CASE_EQ:
         result = mir_build_cmp(g->mu, MIR_CMP_EQ, left, right);
         break;
      case V_BINARY_LOG_NEQ:
      case V_BINARY_CASE_NEQ:
         result = mir_build_cmp(g->mu, MIR_CMP_NEQ, left, right);
         break;
      case V_BINARY_LT:
         result = mir_build_cmp(g->mu, MIR_CMP_LT, left, right);
         break;
      case V_BINARY_LEQ:
         result = mir_build_cmp(g->mu, MIR_CMP_LEQ, left, right);
         break;
      case V_BINARY_GT:
         result = mir_build_cmp(g->mu, MIR_CMP_GT, left, right);
         break;
      case V_BINARY_GEQ:
         result = mir_build_cmp(g->mu, MIR_CMP_GEQ, left, right);
         break;
      case V_BINARY_TIMES:
         result = mir_build_mul(g->mu, ltype, left, right);
         break;
      case V_BINARY_LOG_AND:
         result = mir_build_and(g->mu, vlog_lower_test(g, left),
                                vlog_lower_test(g, right));
         break;
      case V_BINARY_LOG_OR:
         result = mir_build_or(g->mu, vlog_lower_test(g, left),
                               vlog_lower_test(g, right));
         break;
      case V_BINARY_DIVIDE:
         result = mir_build_div(g->mu, ltype, left, right);
         break;
      case V_BINARY_EXP:
         result = mir_build_exp(g->mu, ltype, left, right);
         break;
      case V_BINARY_PLUS:
         result = mir_build_add(g->mu, ltype, left, right);
         break;
      case V_BINARY_MINUS:
         result = mir_build_sub(g->mu, ltype, left, right);
         break;
      default:
         CANNOT_HANDLE(v);
      }
   }

   mir_value_t loaded;
   if (mir_is_null(var))
      loaded = result;
   else {
      mir_build_store(g->mu, var, result);
      mir_build_jump(g->mu, skip_bb);

      mir_set_cursor(g->mu, skip_bb, MIR_APPEND);

      loaded = mir_build_load(g->mu, var);
   }

   return vlog_widen_vector(g, loaded, context);
}

static mir_value_t vlog_lower_operator_assignment(vlog_gen_t *g, vlog_node_t v)
{
   vlog_node_t target = vlog_target(v);

   mir_value_t value = vlog_lower_rvalue(g, vlog_value(v));
   mir_value_t cur = vlog_lower_rvalue(g, target);

   const vlog_assign_t kind = vlog_subkind(v);
   if (kind != V_ASSIGN_EQUALS) {
      mir_type_t type = mir_get_type(g->mu, cur);
      mir_value_t cast = mir_build_cast(g->mu, type, value);

      if (mir_get_class(g->mu, type) == MIR_TYPE_REAL) {
         switch (kind) {
         case V_ASSIGN_PLUS:
            value = mir_build_add(g->mu,type, cur, cast);
            break;
         default:
            CANNOT_HANDLE(v);
         }
      }
      else {
         mir_vec_op_t op;
         switch (kind) {
         case V_ASSIGN_PLUS:     op = MIR_VEC_ADD; break;
         case V_ASSIGN_MINUS:    op = MIR_VEC_SUB; break;
         case V_ASSIGN_TIMES:    op = MIR_VEC_MUL; break;
         case V_ASSIGN_DIVIDE:   op = MIR_VEC_DIV; break;
         case V_ASSIGN_MOD:      op = MIR_VEC_MOD; break;
         case V_ASSIGN_AND:      op = MIR_VEC_BIT_AND; break;
         case V_ASSIGN_OR:       op = MIR_VEC_BIT_OR; break;
         case V_ASSIGN_XOR:      op = MIR_VEC_BIT_XOR; break;
         case V_ASSIGN_SHIFT_LL:
         case V_ASSIGN_SHIFT_LA: op = MIR_VEC_SLL; break;
         case V_ASSIGN_SHIFT_RL: op = MIR_VEC_SRL; break;
         case V_ASSIGN_SHIFT_RA: op = MIR_VEC_SRA; break;
         default:
            CANNOT_HANDLE(v);
         }

         value = mir_build_binary(g->mu, op, type, cur, cast);
      }
   }

   vlog_assign_variable(g, target, value, NULL);
   return value;
}

static mir_value_t vlog_lower_systf_param(vlog_gen_t *g, vlog_node_t v)
{
   switch (vlog_kind(v)) {
   case V_REF:
      switch (vlog_kind(vlog_ref(v))) {
      case V_TF_PORT_DECL:
      case V_FUNC_DECL:
      case V_PARAM_DECL:
      case V_LOCALPARAM:
         return vlog_lower_rvalue(g, v);
      case V_VAR_DECL:
      case V_LOCAL_DECL:
         {
            int hops;
            mir_value_t var = mir_search_object(g->mu, vlog_ref(v), &hops);
            if (mir_is_null(var) || hops > 0)
               return MIR_NULL_VALUE;

            return vlog_lower_rvalue(g, v);
         }
      default:
         return MIR_NULL_VALUE;
      }
   case V_STRING:
   case V_NUMBER:
   case V_EMPTY:
   case V_REAL:
      return MIR_NULL_VALUE;
   case V_UNARY:
   case V_BINARY:
   case V_SYS_FCALL:
   case V_PREFIX:
   case V_POSTFIX:
   case V_BIT_SELECT:
   case V_PART_SELECT:
   case V_COND_EXPR:
   case V_MEMBER_REF:
   case V_HIER_REF:
      // TODO: these should not be evaluated until vpi_get_value is called
      return vlog_lower_rvalue(g, v);
   default:
      CANNOT_HANDLE(v);
   }
}

static mir_value_t vlog_lower_sys_tfcall(vlog_gen_t *g, vlog_node_t v)
{
   const int nparams = vlog_params(v);
   mir_value_t *args LOCAL =
      xmalloc_array((nparams * 3) + 1, sizeof(mir_value_t));
   int actual = 0;
   mir_type_t t_offset = mir_offset_type(g->mu);
   for (int i = 0; i < nparams; i++) {
      mir_value_t arg = vlog_lower_systf_param(g, vlog_param(v, i));
      if (mir_is_null(arg))
         continue;

      mir_type_t type = mir_get_type(g->mu, arg);
      switch (mir_get_class(g->mu, type)) {
      case MIR_TYPE_VEC4:
         args[actual++] = mir_const(g->mu, t_offset, mir_get_size(g->mu, type));
         args[actual++] = arg;
         break;
      case MIR_TYPE_VEC2:
         {
            const int size = mir_get_size(g->mu, type);
            mir_type_t t_vec4 = mir_vec4_type(g->mu, size, false);
            args[actual++] = mir_const(g->mu, t_offset, size);
            args[actual++] = mir_build_cast(g->mu, t_vec4, arg);
         }
         break;
      case MIR_TYPE_REAL:
         args[actual++] = mir_const(g->mu, t_offset, -1);
         args[actual++] = arg;
         args[actual++] = mir_const(g->mu, t_offset, 0); // Padding
         break;
      default:
         should_not_reach_here();
      }
   }

   mir_value_t locus = mir_build_debug_locus(g->mu, vlog_to_object(v));

   mir_type_t type = MIR_NULL_TYPE;
   if (vlog_kind(v) == V_SYS_FCALL) {
      switch (vpi_func_type(vlog_ident(v))) {
      case vpiRealFunc:
         type = mir_double_type(g->mu);
         break;
      case vpiTimeFunc:
         type = mir_vec2_type(g->mu, 64, false);
         break;
      default:
         warn_at(vlog_loc(v), "result type of system function %pQ is "
                 "not known", vlog_ident(v));
         // Fall-through
      case vpiIntFunc:
         type = mir_vec4_type(g->mu, 32, true);
         break;
      }
   }

   mir_value_t result = mir_build_syscall(g->mu, vlog_ident(v), type,
                                          MIR_NULL_STAMP, locus, args, actual);
   mir_build_consume(g->mu, result);
   return result;
}

static mir_value_t vlog_lower_sys_fcall(vlog_gen_t *g, vlog_node_t v)
{
   const vlog_systf_t subk = vlog_subkind(v);
   switch (subk) {
   case V_SYSTF_SIGNED:
   case V_SYSTF_UNSIGNED:
      {
         mir_value_t arg = vlog_lower_rvalue(g, vlog_param(v, 0));
         mir_type_t arg_type = mir_get_type(g->mu, arg), type;
         switch (mir_get_class(g->mu, arg_type)) {
         case MIR_TYPE_VEC2:
            type = mir_vec2_type(g->mu, mir_get_size(g->mu, arg_type),
                                 subk == V_SYSTF_SIGNED);
            break;
         case MIR_TYPE_VEC4:
            type = mir_vec4_type(g->mu, mir_get_size(g->mu, arg_type),
                                 subk == V_SYSTF_SIGNED);
            break;
         default:
            type = arg_type;
            break;
         }

         return mir_build_cast(g->mu, type, arg);
      }
   case V_SYSTF_BITS:
      {
         mir_type_t t_integer = mir_vec4_type(g->mu, 32, true);
         vlog_node_t param = vlog_param(v, 0);
         if (vlog_kind(param) == V_REF) {
            vlog_node_t decl = vlog_ref(param);
            if (is_data_type(decl)) {
               const type_info_t *ti = vlog_type_info(g, decl);
               return mir_const_vec(g->mu, t_integer, ti->size, 0);
            }
         }

         mir_value_t arg = vlog_lower_rvalue(g, param);
         if (mir_is_vector(g->mu, arg)) {
            const int size = mir_get_size(g->mu, mir_get_type(g->mu, arg));
            return mir_const_vec(g->mu, t_integer, size, 0);
         }
         else
            return mir_const_vec(g->mu, t_integer, ~0, ~0);
      }
   default:
      return vlog_lower_sys_tfcall(g, v);
   }
}

static mir_value_t vlog_lower_full_select(vlog_gen_t *g,
                                          const vlog_select_t *select)
{
   if (mir_is_signal(g->mu, select->obj)) {
      mir_value_t data = mir_build_resolved(g->mu, select->obj);
      mir_value_t ptr = mir_build_array_ref(g->mu, data, select->dst_offset);

      switch (mir_get_class(g->mu, select->type)) {
      case MIR_TYPE_VEC2:
      case MIR_TYPE_VEC4:
         if (mir_get_size(g->mu, select->type) == 1) {
            mir_value_t val = mir_build_load(g->mu, ptr);
            return mir_build_pack(g->mu, select->type, val);
         }
         else
            return mir_build_pack(g->mu, select->type, ptr);
      case MIR_TYPE_REAL:
         return mir_build_load(g->mu, ptr);
      default:
         should_not_reach_here();
      }
   }
   else {
      mir_value_t data = select->obj;
      if (mir_is(g->mu, data, MIR_TYPE_POINTER))
         data = mir_build_load(g->mu, data);

      switch (mir_get_class(g->mu, select->type)) {
      case MIR_TYPE_VEC2:
      case MIR_TYPE_VEC4:
         return mir_build_extract(g->mu, select->type, data,
                                  select->dst_offset);
      case MIR_TYPE_CONTEXT:
      case MIR_TYPE_REAL:
         return data;
      default:
         should_not_reach_here();
      }
   }
}

static mir_value_t vlog_lower_partial_select(vlog_gen_t *g,
                                             const vlog_select_t *select)
{
   mir_type_t t_elem = mir_logic_type(g->mu);
   mir_value_t src;
   if (mir_is_signal(g->mu, select->obj)) {
      mir_value_t data = mir_build_resolved(g->mu, select->obj);
      src = mir_build_array_ref(g->mu, data, select->dst_offset);
      t_elem = mir_get_elem(g->mu, mir_get_type(g->mu, src));
   }
   else {
      mir_value_t data = select->obj;
      if (mir_is(g->mu, data, MIR_TYPE_POINTER))
         data = mir_build_load(g->mu, data);

      assert(mir_is_vector(g->mu, data));

      const unsigned size = mir_get_size(g->mu, mir_get_type(g->mu, data));
      mir_type_t t_src_array = mir_carray_type(g->mu, size, t_elem);
      mir_value_t src_tmp = mir_add_var(g->mu, t_src_array, MIR_NULL_STAMP,
                                        ident_uniq("tmp"), MIR_VAR_TEMP);

      mir_build_unpack(g->mu, data, 0, src_tmp);
      src = mir_build_array_ref(g->mu, src_tmp, select->dst_offset);
   }

   mir_type_t t_array = mir_carray_type(g->mu, select->size, t_elem);
   mir_value_t tmp = mir_add_var(g->mu, t_array, MIR_NULL_STAMP,
                                 ident_uniq("tmp"), MIR_VAR_TEMP);

   mir_build_unpack(g->mu, vlog_lower_x(g, select->type), 0, tmp);

   mir_value_t dst = mir_build_array_ref(g->mu, tmp, select->src_offset);
   mir_build_copy(g->mu, dst, src, select->count);

   return mir_build_pack(g->mu, select->type, tmp);
}

static mir_value_t vlog_lower_rvalue_select(vlog_gen_t *g, vlog_node_t v)
{
   vlog_select_t select = vlog_lower_select(g, v);

   int64_t dst_count_const;
   if (mir_get_const(g->mu, select.count, &dst_count_const)) {
      if (dst_count_const == select.size)
         return vlog_lower_full_select(g, &select);
      else if (dst_count_const == 0)
         return vlog_lower_x(g, select.type);
   }

   return vlog_lower_partial_select(g, &select);
}

static mir_value_t vlog_context_for_call(vlog_gen_t *g, vlog_node_t v)
{
   if (mir_get_kind(g->mu) == MIR_UNIT_THUNK || g->constfunc)
      return MIR_NULL_VALUE;

   return mir_build_context_upref(g->mu, 1);  // XXX
}

static mir_value_t vlog_lower_with_context(vlog_gen_t *g, vlog_node_t v,
                                           mir_type_t context)
{
   PUSH_DEBUG_INFO(g->mu, v);

   switch (vlog_kind(v)) {
   case V_REF:
   case V_BIT_SELECT:
   case V_PART_SELECT:
   case V_MEMBER_REF:
      return vlog_widen_vector(g, vlog_lower_rvalue_select(g, v), context);
   case V_HIER_REF:
      {
         if (!vlog_has_ref(v))
            fatal_at(vlog_loc(v), "unbound hierarchical reference");

         vlog_node_t decl = vlog_ref(v);
         const type_info_t *ti = vlog_type_info(g, vlog_type(decl));

         mir_value_t locus = mir_build_debug_locus(g->mu, vlog_to_object(v));
         ident_t scope = mir_get_parent(g->mu);

         mir_value_t ptr = mir_build_bind_external(g->mu, locus, scope,
                                                   ti->signal, ti->stamp,
                                                   NULL, 0);

         mir_value_t nets = mir_build_load(g->mu, ptr);
         mir_value_t data = mir_build_resolved(g->mu, nets);

         if (ti->size == 1)
            data = mir_build_load(g->mu, data);

         mir_value_t packed = mir_build_pack(g->mu, ti->type, data);
         return vlog_widen_vector(g, packed, context);
      }
   case V_NUMBER:
   case V_STRING:
      {
         number_t num = vlog_number(v);
         const int width = number_width(num);
         const bool issigned = number_signed(num);

         const uint64_t *abits, *bbits;
         number_get(num, &abits, &bbits);

         mir_type_t t_full = mir_vec4_type(g->mu, width, issigned);

         if (width <= 64) {
            mir_value_t vec = mir_const_vec(g->mu, t_full, abits[0], bbits[0]);
            return vlog_widen_vector(g, vec, context);
         }

         mir_type_t t_low = mir_vec4_type(g->mu, 64, false);
         mir_value_t low = mir_const_vec(g->mu, t_low, abits[0], bbits[0]);

         mir_value_t full = mir_build_cast(g->mu, t_full, low);

         mir_type_t t_offset = mir_offset_type(g->mu);

         for (int i = 64; i < width; i += 64) {
            const uint64_t aword = abits[i / 64];
            const uint64_t bword = bbits[i / 64];
            if (aword == 0 && bword == 0)
               continue;

            const int part_size = MIN(width - i, 64);

            mir_type_t t_part = mir_vec4_type(g->mu, part_size, issigned);
            mir_value_t part = mir_const_vec(g->mu, t_part, aword, bword);

            mir_value_t pos = mir_const(g->mu, t_offset, width - i - part_size);
            full = mir_build_insert(g->mu, part, full, pos);
         }

         return vlog_widen_vector(g, full, context);
      }
   case V_BINARY:
      return vlog_lower_binary(g, v, context);
   case V_UNARY:
      return vlog_lower_unary(g, v, context);
   case V_SYS_FCALL:
      return vlog_lower_sys_fcall(g, v);
   case V_MIN_TYP_MAX:
      return vlog_lower_with_context(g, vlog_value(v), context);
   case V_CONCAT:
      {
         int size = 0, repeat = 1;
         const int nparams = vlog_params(v);
         mir_value_t *inputs LOCAL =
            xmalloc_array(nparams, sizeof(mir_value_t));

         for (int i = 0; i < nparams; i++) {
            inputs[i] = vlog_lower_rvalue(g, vlog_param(v, i));
            assert(mir_is_vector(g->mu, inputs[i]));

            mir_type_t part_type = mir_get_type(g->mu, inputs[i]);
            int part_size = mir_get_size(g->mu, part_type);

            if (mir_get_class(g->mu, part_type) != MIR_TYPE_VEC4) {
               mir_type_t t_vec4 = mir_vec4_type(g->mu, part_size, false);
               inputs[i] = mir_build_cast(g->mu, t_vec4, inputs[i]);
            }

            size += part_size;
         }

         if (vlog_has_value(v)) {
            int64_t cval;
            vlog_get_const(vlog_value(v), &cval);
            size *= (repeat = MAX(0, cval));
         }

         mir_type_t type = mir_vec4_type(g->mu, size, false);

         mir_value_t result;
         if (size <= 64)
            result = mir_const_vec(g->mu, type, 0, 0);
         else {
            mir_type_t t_bit = mir_vec4_type(g->mu, 1, false);
            mir_value_t zero = mir_const_vec(g->mu, t_bit, 0, 0);
            result = mir_build_cast(g->mu, type, zero);
         }

         mir_type_t t_offset = mir_offset_type(g->mu);

         for (int i = 0, pos = size; i < repeat; i++) {
            for (int j = nparams - 1; j >= 0; j--) {
               pos -= mir_get_size(g->mu, mir_get_type(g->mu, inputs[j]));
               result = mir_build_insert(g->mu, inputs[j], result,
                                         mir_const(g->mu, t_offset, pos));
            }
         }

         return vlog_widen_vector(g, result, context);
      }
   case V_PREFIX:
      {
         vlog_node_t target = vlog_target(v);

         mir_value_t prev = vlog_lower_rvalue(g, target);
         mir_type_t type = mir_get_type(g->mu, prev);
         mir_value_t one = mir_const_vec(g->mu, type, 1, 0);
         mir_value_t inc =
            mir_build_binary(g->mu, MIR_VEC_ADD, type, prev, one);

         vlog_assign_variable(g, target, inc, NULL);

         return inc;
      }
   case V_POSTFIX:
      {
         vlog_node_t target = vlog_target(v);

         mir_value_t prev = vlog_lower_rvalue(g, target);
         mir_type_t type = mir_get_type(g->mu, prev);
         mir_value_t one = mir_const_vec(g->mu, type, 1, 0);
         mir_value_t inc =
            mir_build_binary(g->mu, MIR_VEC_ADD, type, prev, one);

         vlog_assign_variable(g, target, inc, NULL);

         return inc;
      }
   case V_COND_EXPR:
      {
         // See 1800-2023 section 11.4.11 for semantics

         vlog_node_t left_expr = vlog_left(v);
         vlog_node_t right_expr = vlog_right(v);

         mir_value_t value = vlog_lower_rvalue(g, vlog_value(v));

         const bool is_signed =
            vlog_is_signed(left_expr) && vlog_is_signed(right_expr);

         unsigned size = MAX(vlog_width(left_expr), vlog_width(right_expr));
         mir_type_t type;
         if (mir_is_null(context))
            type = mir_vec4_type(g->mu, size, is_signed);
         else {
            mir_class_t class = mir_get_class(g->mu, context);
            if (class == MIR_TYPE_VEC2 || class == MIR_TYPE_VEC4) {
               size = MAX(size, mir_get_size(g->mu, context));
               type = mir_vec4_type(g->mu, size, is_signed);
            }
            else
               type = context;
         }

         mir_value_t left = vlog_lower_with_context(g, left_expr, type);
         mir_value_t right = vlog_lower_with_context(g, right_expr, type);

         if (!is_signed) {
            left = vlog_cast_unsigned(g, left);
            right = vlog_cast_unsigned(g, right);
         }

         mir_value_t lcast = vlog_lower_cast(g, type, left);
         mir_value_t rcast = vlog_lower_cast(g, type, right);

         const bool merge_x = mir_is(g->mu, value, MIR_TYPE_VEC4)
            && mir_is_vector(g->mu, lcast)
            && mir_is_vector(g->mu, rcast);

         if (merge_x) {
            mir_type_t t_test = mir_get_type(g->mu, value);
            mir_value_t zero = vlog_lower_zero(g, t_test);
            mir_value_t cmp = mir_build_binary(g->mu, MIR_VEC_LOG_NEQ, t_test,
                                               value, zero);
            return mir_build_ternary(g->mu, type, cmp, lcast, rcast);
         }
         else {
            mir_value_t cmp = vlog_lower_test(g, value);
            return mir_build_select(g->mu, type, cmp, lcast, rcast);
         }
      }
   case V_USER_FCALL:
      {
         vlog_node_t decl = vlog_ref(v);
         ident_t func = ident_prefix(vlog_ident2(decl), vlog_ident(decl), '.');
         if (mir_get_kind(g->mu) == MIR_UNIT_THUNK || g->constfunc)
            func = ident_sprintf("%s@const", istr(func));

         const int nparams = vlog_params(v);
         mir_value_t *args LOCAL =
            xmalloc_array(nparams + 1, sizeof(mir_value_t));

         mir_value_t context = vlog_context_for_call(g, decl);

         int pos = 0;
         if (!mir_is_null(context))
            args[pos++] = context;

         for (int i = 0; i < nparams; i++) {
            mir_value_t value = vlog_lower_rvalue(g, vlog_param(v, i));
            vlog_node_t dt = vlog_type(vlog_port(decl, i));
            const type_info_t *ti = vlog_type_info(g, dt);
            args[pos++] = vlog_lower_cast(g, ti->type, value);
         }

         const type_info_t *ti = vlog_type_info(g, vlog_type(decl));
         mir_value_t result = mir_build_fcall(g->mu, func, ti->type,
                                              MIR_NULL_STAMP, args, pos);
         mir_build_consume(g->mu, result);
         return result;
      }
   case V_REAL:
      {
         mir_type_t t_double = mir_double_type(g->mu);
         return mir_const_real(g->mu, t_double, vlog_dval(v));
      }
   case V_OP_ASSIGN:
      return vlog_lower_operator_assignment(g, v);
   case V_CLASS_NEW:
      {
         const type_info_t *ti = vlog_type_info(g, vlog_type(v));
         mir_value_t context = mir_build_context_upref(g->mu, 0);  // XXX
         return mir_build_protected_init(g->mu, ti->type, context,
                                         MIR_NULL_VALUE, MIR_NULL_VALUE);
      }
   case V_DYNAMIC_NEW:
      {
         const type_info_t *ti = vlog_type_info(g, vlog_type(v));
         mir_type_t t_offset = mir_offset_type(g->mu);
         mir_type_t t_bool = mir_bool_type(g->mu);

         mir_value_t count =
            vlog_lower_cast(g, t_offset, vlog_lower_rvalue(g, vlog_value(v)));
         mir_value_t data = mir_build_alloc(g->mu, ti->type, ti->stamp, count);

         mir_value_t left = mir_const(g->mu, t_offset, 0);
         mir_value_t right =
            mir_build_sub(g->mu, t_offset, count, mir_const(g->mu, t_offset, 1));
         mir_value_t dir = mir_const(g->mu, t_bool, RANGE_TO);

         mir_dim_t dims[1] = { { left, right, dir } };
         return mir_build_wrap(g->mu, data, dims, 1);
      }
   case V_NULL:
      {
         const type_info_t *ti = vlog_type_info(g, vlog_type(v));
         return mir_build_null(g->mu, ti->type);
      }
   default:
      CANNOT_HANDLE(v);
   }
}

static mir_value_t vlog_lower_rvalue(vlog_gen_t *g, vlog_node_t v)
{
   return vlog_lower_with_context(g, v, MIR_NULL_TYPE);
}

static mir_value_t vlog_lower_time(vlog_gen_t *g, vlog_node_t v)
{
   mir_type_t t_time = mir_time_type(g->mu);

   if (vlog_kind(v) == V_NUMBER) {
      number_t num = vlog_number(v);
      return mir_const(g->mu, t_time, number_integer(num));
   }
   else {
      mir_value_t value = vlog_lower_rvalue(g, v);
      return vlog_lower_cast(g, t_time, value);
   }
}

static mir_value_t vlog_or_triggers(vlog_gen_t *g, int n, ...)
{
   va_list ap;
   va_start(ap, n);

   mir_value_t or = MIR_NULL_VALUE;
   for (int i = 0; i < n; i++) {
      mir_value_t t = va_arg(ap, mir_value_t);
      if (mir_is_null(t))
         continue;
      else if (mir_is_null(or))
         or = t;
      else
         or = mir_build_or_trigger(g->mu, or, t);
   }

   va_end(ap);
   return or;
}

static void vlog_lower_edge_fn(mir_unit_t *mu, vlog_edge_t edge)
{
   mir_type_t t_context = mir_context_type(mu, ident_new("dummy"));
   mir_type_t t_bool = mir_bool_type(mu);
   mir_type_t t_offset = mir_offset_type(mu);
   mir_type_t t_uint8 = mir_int_type(mu, 0, UINT8_MAX);
   mir_type_t t_logic = mir_vec4_type(mu, 1, false);
   mir_type_t t_signal = mir_signal_type(mu, t_uint8);

   mir_set_result(mu, t_bool);

   mir_add_param(mu, t_context, MIR_NULL_STAMP, ident_new("context"));
   mir_value_t nets = mir_add_param(mu, t_signal, MIR_NULL_STAMP,
                                    ident_new("arg"));

   mir_value_t cur_ptr = mir_build_resolved(mu, nets);
   mir_value_t cur_val = mir_build_load(mu, cur_ptr);
   mir_value_t cur_packed = mir_build_pack(mu, t_logic, cur_val);
   mir_value_t cur_cmp = mir_build_unpack(mu, cur_packed, 0, MIR_NULL_VALUE);

   mir_value_t last_ptr = mir_build_last_value(mu, nets);
   mir_value_t last_val = mir_build_load(mu, last_ptr);
   mir_value_t last_packed = mir_build_pack(mu, t_logic, last_val);
   mir_value_t last_cmp = mir_build_unpack(mu, last_packed, 0, MIR_NULL_VALUE);

   // Truth table from 1800-2023 section 9.4.2
   static const uint8_t table_entries[] = {
      NOEDGE,  POSEDGE, POSEDGE, POSEDGE,
      NEGEDGE, NOEDGE,  NEGEDGE, NEGEDGE,
      NEGEDGE, POSEDGE, NOEDGE,  NOEDGE,
      NEGEDGE, POSEDGE, NOEDGE,  NOEDGE,
   };

   mir_value_t tmp[ARRAY_LEN(table_entries)];
   for (int i = 0; i < ARRAY_LEN(table_entries); i++)
      tmp[i] = mir_const(mu, t_uint8, table_entries[i]);

   mir_type_t t_table = mir_carray_type(mu, ARRAY_LEN(table_entries), t_uint8);
   mir_value_t table = mir_const_array(mu, t_table, tmp, ARRAY_LEN(tmp));
   mir_value_t address = mir_build_address_of(mu, table);
   mir_value_t stride = mir_const(mu, t_offset, 4);

   mir_value_t args[2] = { last_cmp, cur_cmp };
   mir_value_t ptr = mir_build_table_ref(mu, address, stride, args, 2);
   mir_value_t entry = mir_build_load(mu, ptr);

   mir_value_t edge_val = mir_const(mu, t_uint8, edge);
   mir_value_t cmp = mir_build_cmp(mu, MIR_CMP_EQ, entry, edge_val);
   mir_build_return(mu, cmp);

   mir_optimise(mu, MIR_PASS_O0);
}

static void vlog_lower_posedge_fn(mir_unit_t *mu, object_t *obj)
{
   vlog_lower_edge_fn(mu, POSEDGE);
}

static void vlog_lower_negedge_fn(mir_unit_t *mu, object_t *obj)
{
   vlog_lower_edge_fn(mu, NEGEDGE);
}

static mir_value_t vlog_lower_trigger(vlog_gen_t *g, vlog_node_t v)
{
   const vlog_kind_t kind = vlog_kind(v);
   switch (kind) {
   case V_REF:
   case V_HIER_REF:
      {
         switch (vlog_kind(vlog_ref(v))) {
         case V_PORT_DECL:
         case V_NET_DECL:
         case V_VAR_DECL:
         case V_LOCAL_DECL:
            {
               mir_type_t t_offset = mir_offset_type(g->mu);

               vlog_select_t lvalue = vlog_lower_select(g, v);
               int total_size = lvalue.size;
               if (vlog_kind(v) == V_REF)
                  total_size *= vlog_size(vlog_ref(v));

               mir_value_t count = mir_const(g->mu, t_offset, total_size);

               return mir_build_level_trigger(g->mu, lvalue.obj, count);
            }
         case V_PARAM_DECL:
         case V_LOCALPARAM:
            return MIR_NULL_VALUE;
         default:
            CANNOT_HANDLE(v);
         }
      }
      break;
   case V_BIT_SELECT:
   case V_PART_SELECT:
      {
         mir_value_t trigger;
         vlog_node_t prefix = vlog_longest_static_prefix(v);
         if (prefix == v) {
            vlog_select_t lvalue = vlog_lower_select(g, v);

            mir_value_t nets =
               mir_build_array_ref(g->mu, lvalue.obj, lvalue.dst_offset);

            trigger = mir_build_level_trigger(g->mu, nets, lvalue.count);
         }
         else
            trigger = vlog_lower_trigger(g, prefix);

         if (kind == V_BIT_SELECT) {
            const int nparams = vlog_params(v);
            for (int i = 0; i < nparams; i++) {
               mir_value_t p = vlog_lower_trigger(g, vlog_param(v, i));
               trigger = vlog_or_triggers(g, 2, trigger, p);
            }
         }
         else {
            mir_value_t left = vlog_lower_trigger(g, vlog_left(v));
            trigger = vlog_or_triggers(g, 2, trigger, left);
         }

         return trigger;
      }
   case V_EVENT:
      {
         const v_event_kind_t kind = vlog_subkind(v);
         if (kind == V_EVENT_LEVEL)
            return vlog_lower_trigger(g, vlog_value(v));
         else {
            vlog_select_t lvalue = vlog_lower_select(g, vlog_value(v));

            ident_t func;
            switch (kind) {
            case V_EVENT_POSEDGE:
               func = ident_new("@posedge");
               mir_defer(mir_get_context(g->mu), func, NULL, MIR_UNIT_FUNCTION,
                         vlog_lower_posedge_fn, NULL);
               break;
            case V_EVENT_NEGEDGE:
               func = ident_new("@negedge");
               mir_defer(mir_get_context(g->mu), func, NULL, MIR_UNIT_FUNCTION,
                         vlog_lower_negedge_fn, NULL);
               break;
            default:
               should_not_reach_here();
            }

            mir_value_t context = mir_build_context_upref(g->mu, 0);
            mir_value_t args[] = { context, lvalue.obj };
            return mir_build_function_trigger(g->mu, func, args, 2);
         }
      }
   case V_NUMBER:
      return MIR_NULL_VALUE;
   case V_BINARY:
      {
         mir_value_t left = vlog_lower_trigger(g, vlog_left(v));
         mir_value_t right = vlog_lower_trigger(g, vlog_right(v));

         return vlog_or_triggers(g, 2, left, right);
      }
   case V_UNARY:
      return vlog_lower_trigger(g, vlog_value(v));
   case V_COND_EXPR:
      {
         mir_value_t value = vlog_lower_trigger(g, vlog_value(v));
         mir_value_t left = vlog_lower_trigger(g, vlog_left(v));
         mir_value_t right = vlog_lower_trigger(g, vlog_right(v));

         return vlog_or_triggers(g, 3, value, left, right);
      }
   case V_CONCAT:
   case V_USER_FCALL:
      {
         mir_value_t trigger = MIR_NULL_VALUE;
         const int nparams = vlog_params(v);
         for (int i = 0; i < nparams; i++) {
            mir_value_t p = vlog_lower_trigger(g, vlog_param(v, i));
            trigger = vlog_or_triggers(g, 2, trigger, p);
         }

         return trigger;
      }
   default:
      CANNOT_HANDLE(v);
   }
}

static mir_value_t vlog_lower_trigger_var(vlog_gen_t *g, vlog_node_t v)
{
   assert(vlog_kind(v) == V_EVENT_CONTROL);

   int hops = 0;
   mir_value_t var = mir_search_object(g->mu, v, &hops);
   assert(mir_is_null(var) || hops == 0);

   if (!mir_is_null(var))
      return var;

   mir_value_t trigger = MIR_NULL_VALUE;

   const int nparams = vlog_params(v);
   for (int i = 0; i < nparams; i++) {
      mir_value_t p = vlog_lower_trigger(g, vlog_param(v, i));
      trigger = vlog_or_triggers(g, 2, trigger, p);
   }

   if (mir_is_null(trigger))
      return MIR_NULL_VALUE;

   mir_type_t t_trigger = mir_trigger_type(g->mu);
   var = mir_add_var(g->mu, t_trigger, MIR_NULL_STAMP,
                     ident_uniq("trigger"), 0);
   mir_build_store(g->mu, var, trigger);

   mir_put_object(g->mu, v, var);
   return var;
}

static void vlog_lower_timing(vlog_gen_t *g, vlog_node_t v, gen_stack_t *gs)
{
   vlog_node_t ctrl = vlog_value(v);
   switch (vlog_kind(ctrl)) {
   case V_DELAY_CONTROL:
      {
         mir_type_t t_time = mir_time_type(g->mu);
         mir_value_t delay = vlog_lower_rvalue(g, vlog_value(ctrl));
         mir_value_t cast = mir_build_cast(g->mu, t_time, delay);

         int64_t dconst;
         if (mir_get_const(g->mu, cast, &dconst) && dconst == 0)
            mir_build_sched_inactive(g->mu);
         else
            mir_build_sched_process(g->mu, cast);

         mir_block_t wait_bb = mir_add_block(g->mu);
         mir_build_wait(g->mu, wait_bb);

         mir_set_cursor(g->mu, wait_bb, MIR_APPEND);
      }
      break;
   case V_EVENT_CONTROL:
      {
         mir_value_t trigger_var = vlog_lower_trigger_var(g, ctrl);
         if (!mir_is_null(trigger_var)) {
            mir_value_t trigger = mir_build_load(g->mu, trigger_var);
            mir_build_sched_event(g->mu, trigger, MIR_NULL_VALUE);
         }

         mir_block_t wait_bb = mir_add_block(g->mu);
         mir_build_wait(g->mu, wait_bb);

         mir_set_cursor(g->mu, wait_bb, MIR_APPEND);

         if (!mir_is_null(trigger_var)) {
            mir_value_t trigger = mir_build_load(g->mu, trigger_var);
            mir_build_clear_event(g->mu, trigger, MIR_NULL_VALUE);
         }
      }
      break;
   default:
      CANNOT_HANDLE(ctrl);
   }

   vlog_lower_stmts(g, v, gs);
}

static mir_value_t vlog_lower_default_value(vlog_gen_t *g,
                                            const type_info_t *ti)
{
   switch (mir_get_class(g->mu, ti->type)) {
   case MIR_TYPE_VEC2:
      if (ti->size <= 64)
         return mir_const_vec(g->mu, ti->type, 0, 0);
      else {
         mir_type_t t_bit = mir_vec2_type(g->mu, 1, false);
         mir_value_t zero = mir_const_vec(g->mu, t_bit, 0, 0);
         return mir_build_cast(g->mu, ti->type, zero);
      }
   case MIR_TYPE_VEC4:
      return vlog_lower_x(g, ti->type);
   case MIR_TYPE_REAL:
      return mir_const_real(g->mu, ti->type, 0.0);
   default:
      should_not_reach_here();
   }
}

static void vlog_lower_blocking_assignment(vlog_gen_t *g, vlog_node_t v)
{
   if (vlog_has_delay(v)) {
      vlog_node_t delay = vlog_delay(v);
      assert(vlog_kind(delay) == V_DELAY_CONTROL);

      mir_build_sched_process(g->mu, vlog_lower_time(g, vlog_value(delay)));

      mir_block_t delay_bb = mir_add_block(g->mu);
      mir_build_wait(g->mu, delay_bb);

      mir_set_cursor(g->mu, delay_bb, MIR_APPEND);
   }

   vlog_assign_variable(g, vlog_target(v), MIR_NULL_VALUE, vlog_value(v));
}

static void vlog_lower_non_blocking_assignment(vlog_gen_t *g, vlog_node_t v)
{
   vlog_node_t target = vlog_target(v);

   mir_class_t class = MIR_TYPE_VEC4;
   unsigned nlvalues = 1, targetsz = 0;
   vlog_select_t lvalue1, *lvalues = &lvalue1;
   if (vlog_kind(target) == V_CONCAT) {
      nlvalues = vlog_count_lvalues(target);
      lvalues = xmalloc_array(nlvalues, sizeof(vlog_select_t));

      unsigned index = 0;
      vlog_lower_lvalues(g, target, lvalues, NULL, &index);
      assert(index == nlvalues);

      for (int i = 0; i < nlvalues; i++)
         targetsz += lvalues[i].size;
   }
   else {
      lvalue1 = vlog_lower_select(g, target);
      targetsz = lvalue1.size;
      class = mir_get_class(g->mu, lvalue1.type);
   }

   mir_type_t t_time = mir_time_type(g->mu);
   mir_type_t t_offset = mir_offset_type(g->mu);

   mir_value_t unpacked;
   if (class == MIR_TYPE_VEC2 || class == MIR_TYPE_VEC4) {
      mir_type_t t_vec = mir_vec4_type(g->mu, targetsz, false);

      mir_value_t value = vlog_lower_with_context(g, vlog_value(v), t_vec);
      mir_value_t resize = vlog_lower_cast(g, t_vec, value);
      assert(mir_is_vector(g->mu, resize));

      mir_value_t tmp = MIR_NULL_VALUE;
      if (targetsz > 1) {
         mir_type_t t_elem = mir_logic_type(g->mu);
         mir_type_t t_array = mir_carray_type(g->mu, targetsz, t_elem);
         tmp = vlog_get_temp(g, t_array);
      }

      const uint8_t strength = vlog_is_net(target) ? ST_STRONG : 0;
      unpacked = mir_build_unpack(g->mu, resize, strength, tmp);
   }
   else {
      mir_value_t value =
         vlog_lower_with_context(g, vlog_value(v), lvalues[0].type);
      unpacked = vlog_lower_cast(g, lvalues[0].type, value);
   }

   mir_value_t after;
   if (vlog_has_delay(v)) {
      vlog_node_t delay = vlog_delay(v);
      assert(vlog_kind(delay) == V_DELAY_CONTROL);

      after = vlog_lower_time(g, vlog_value(delay));
   }
   else
      after = mir_const(g->mu, t_time, 0);

   for (int i = 0, offset = 0; i < nlvalues;
        offset += lvalues[i].size, i++) {
      mir_value_t nets = mir_build_array_ref(g->mu, lvalues[i].obj,
                                             lvalues[i].dst_offset);

      mir_block_t merge_bb = MIR_NULL_BLOCK;

      int64_t count_const;
      if (mir_get_const(g->mu, lvalues[i].count, &count_const)) {
         if (count_const == 0) {
            mir_comment(g->mu, "Out-of-range assignment");
            continue;
         }
      }
      else {
         mir_block_t guarded_bb = mir_add_block(g->mu);
         merge_bb = mir_add_block(g->mu);

         mir_value_t overlaps = mir_build_cmp(g->mu, MIR_CMP_NEQ,
                                              lvalues[i].count,
                                              mir_const(g->mu, t_offset, 0));
         mir_build_cond(g->mu, overlaps, guarded_bb, merge_bb);

         mir_set_cursor(g->mu, guarded_bb, MIR_APPEND);
      }

      if (class == MIR_TYPE_VEC2 || class == MIR_TYPE_VEC4) {
         mir_value_t pos = mir_build_add(g->mu, t_offset,
                                         mir_const(g->mu, t_offset, offset),
                                         lvalues[i].src_offset);
         mir_value_t src = mir_build_array_ref(g->mu, unpacked, pos);
         mir_build_sched_deposit(g->mu, nets, lvalues[i].count, src, after);
      }
      else
         mir_build_sched_deposit(g->mu, nets, lvalues[i].count,
                                 unpacked, after);

      if (!mir_is_null(merge_bb)) {
         mir_build_jump(g->mu, merge_bb);
         mir_set_cursor(g->mu, merge_bb, MIR_APPEND);
      }
   }
}

static void vlog_lower_if(vlog_gen_t *g, vlog_node_t v, gen_stack_t *gs)
{
   mir_block_t exit_bb = MIR_NULL_BLOCK;

   const int nconds = vlog_conds(v);
   for (int i = 0; i < nconds; i++) {
      vlog_node_t c = vlog_cond(v, i);
      mir_block_t next_bb = MIR_NULL_BLOCK;

      if (vlog_has_value(c)) {
         mir_value_t value = vlog_lower_rvalue(g, vlog_value(c));
         mir_value_t cmp = vlog_lower_test(g, value);

         mir_block_t btrue = mir_add_block(g->mu);

         if (i == nconds - 1) {
            if (mir_is_null(exit_bb))
               exit_bb = mir_add_block(g->mu);
            next_bb = exit_bb;
         }
         else
            next_bb = mir_add_block(g->mu);

         mir_build_cond(g->mu, cmp, btrue, next_bb);

         mir_set_cursor(g->mu, btrue, MIR_APPEND);
      }

      vlog_lower_stmts(g, c, gs);

      if (!mir_block_finished(g->mu, MIR_NULL_BLOCK)) {
         if (mir_is_null(exit_bb))
            exit_bb = mir_add_block(g->mu);
         mir_build_jump(g->mu, exit_bb);
      }

      if (mir_is_null(next_bb))
         break;

      mir_set_cursor(g->mu, next_bb, MIR_APPEND);
   }

   if (!mir_is_null(exit_bb))
      mir_set_cursor(g->mu, exit_bb, MIR_APPEND);
}

static void vlog_lower_forever(vlog_gen_t *g, vlog_node_t v, gen_stack_t *gs)
{
   mir_block_t body_bb = mir_add_block(g->mu);
   mir_build_jump(g->mu, body_bb);

   mir_set_cursor(g->mu, body_bb, MIR_APPEND);

   vlog_lower_stmts(g, v, gs);

   mir_build_jump(g->mu, body_bb);
}

static void vlog_lower_repeat(vlog_gen_t *g, vlog_node_t v, gen_stack_t *gs)
{
   mir_type_t t_offset = mir_offset_type(g->mu);
   mir_value_t i_var = mir_add_var(g->mu, t_offset, MIR_NULL_STAMP,
                                   ident_uniq("i"), 0);
   mir_value_t zero = mir_const(g->mu, t_offset, 0);
   mir_build_store(g->mu, i_var, zero);

   mir_value_t limit_var = mir_add_var(g->mu, t_offset, MIR_NULL_STAMP,
                                       ident_uniq("limit"), MIR_VAR_CONST);

   mir_value_t rvalue = vlog_lower_rvalue(g, vlog_value(v));
   mir_value_t limit = vlog_lower_cast(g, t_offset, rvalue);
   mir_build_store(g->mu, limit_var, limit);

   mir_value_t enter = mir_build_cmp(g->mu, MIR_CMP_LT, zero, limit);

   mir_block_t body_bb = mir_add_block(g->mu);
   mir_block_t cont_bb = mir_add_block(g->mu);
   mir_build_cond(g->mu, enter, body_bb, cont_bb);

   mir_set_cursor(g->mu, body_bb, MIR_APPEND);

   vlog_lower_stmts(g, v, gs);

   if (!mir_block_finished(g->mu, MIR_NULL_BLOCK)) {
      mir_value_t i_val = mir_build_load(g->mu, i_var);
      mir_value_t one = mir_const(g->mu, t_offset, 1);
      mir_value_t next = mir_build_add(g->mu, t_offset, i_val, one);
      mir_build_store(g->mu, i_var, next);

      mir_value_t limit_load = mir_build_load(g->mu, limit_var);
      mir_value_t done = mir_build_cmp(g->mu, MIR_CMP_LT, next, limit_load);
      mir_build_cond(g->mu, done, body_bb, cont_bb);
   }

   mir_set_cursor(g->mu, cont_bb, MIR_APPEND);
}

static void vlog_lower_while(vlog_gen_t *g, vlog_node_t v, gen_stack_t *gs)
{
   mir_block_t test_bb = mir_add_block(g->mu);
   mir_block_t body_bb = mir_add_block(g->mu);
   mir_block_t cont_bb = mir_add_block(g->mu);

   mir_build_jump(g->mu, test_bb);

   mir_set_cursor(g->mu, test_bb, MIR_APPEND);

   mir_value_t rvalue = vlog_lower_rvalue(g, vlog_value(v));
   mir_value_t test = vlog_lower_test(g, rvalue);
   mir_build_cond(g->mu, test, body_bb, cont_bb);

   mir_set_cursor(g->mu, body_bb, MIR_APPEND);

   vlog_lower_stmts(g, v, gs);

   if (!mir_block_finished(g->mu, MIR_NULL_BLOCK))
      mir_build_jump(g->mu, test_bb);

   mir_set_cursor(g->mu, cont_bb, MIR_APPEND);
}

static void vlog_lower_for_loop(vlog_gen_t *g, vlog_node_t v, gen_stack_t *gs)
{
   mir_comment(g->mu, "Begin for loop");

   vlog_node_t init = vlog_left(v);
   assert(vlog_kind(init) == V_FOR_INIT);

   vlog_lower_locals(g, init);
   vlog_lower_stmts(g, init, gs);

   mir_block_t body_bb = mir_add_block(g->mu);
   mir_block_t step_bb = mir_add_block(g->mu);
   mir_block_t test_bb = mir_add_block(g->mu);
   mir_block_t exit_bb = mir_add_block(g->mu);

   mir_build_jump(g->mu, test_bb);

   mir_set_cursor(g->mu, test_bb, MIR_APPEND);

   mir_comment(g->mu, "For loop test");

   mir_value_t expr = vlog_lower_rvalue(g, vlog_value(v));
   mir_value_t test = vlog_lower_test(g, expr);
   mir_build_cond(g->mu, test, body_bb, exit_bb);

   mir_set_cursor(g->mu, body_bb, MIR_APPEND);

   mir_comment(g->mu, "For loop body");

   vlog_lower_stmts(g, v, gs);

   if (!mir_block_finished(g->mu, MIR_NULL_BLOCK))
      mir_build_jump(g->mu, step_bb);

   mir_set_cursor(g->mu, step_bb, MIR_APPEND);

   mir_comment(g->mu, "For loop step");

   vlog_node_t step = vlog_right(v);
   assert(vlog_kind(step) == V_FOR_STEP);

   const int nstmts = vlog_stmts(step);
   for (int i = 0; i < nstmts; i++)
      vlog_lower_rvalue(g, vlog_stmt(step, i));

   mir_build_jump(g->mu, test_bb);

   mir_set_cursor(g->mu, exit_bb, MIR_APPEND);

   mir_comment(g->mu, "End for loop");
}

static void vlog_lower_disable(vlog_gen_t *g, vlog_node_t v, gen_stack_t *gs)
{
   ident_t name = vlog_ident(v);

   for (gen_stack_t *it = gs; it != NULL; it = it->up) {
      if (it->block != NULL && it->block->name == name) {
         mir_build_jump(g->mu, it->block->exit_bb);
         return;
      }
   }
}

static void vlog_lower_case(vlog_gen_t *g, vlog_node_t v, gen_stack_t *gs)
{
   mir_comment(g->mu, "Begin case statement");

   mir_value_t value = vlog_lower_rvalue(g, vlog_value(v));
   bool is_real = mir_is(g->mu, value, MIR_TYPE_REAL);

   const int nitems = vlog_stmts(v);
   mir_block_t *blocks LOCAL = xmalloc_array(nitems, sizeof(mir_block_t));

   mir_vec_op_t op;
   switch (vlog_subkind(v)) {
   case V_CASE_NORMAL: op = MIR_VEC_CASE_EQ; break;
   case V_CASE_X:      op = MIR_VEC_CASEX_EQ; break;
   case V_CASE_Z:      op = MIR_VEC_CASEZ_EQ; break;
   default:            should_not_reach_here();
   }

   int nexprs = 0, default_item = -1;
   for (int i = 0; i < nitems; i++) {
      vlog_node_t item = vlog_stmt(v, i);
      assert(vlog_kind(item) == V_CASE_ITEM);

      const int nparams = vlog_params(item);
      if (nparams == 0)
         default_item = i;

      nexprs += nparams;
   }

   mir_value_t *exprs LOCAL = xmalloc_array(nexprs, sizeof(mir_value_t));

   // See 1800-2023 section 12.5 for type rules

   mir_type_t value_type = mir_get_type(g->mu, value);

   bool is_signed = is_real ? false : mir_get_signed(g->mu, value_type);
   int width = is_real ? 0 : mir_get_size(g->mu, value_type);

   for (int i = 0, nexpr = 0; i < nitems; i++) {
      vlog_node_t item = vlog_stmt(v, i);
      assert(vlog_kind(item) == V_CASE_ITEM);

      blocks[i] = mir_add_block(g->mu);

      const int nparams = vlog_params(item);
      for (int j = 0; j < nparams; j++) {
         mir_value_t expr = vlog_lower_rvalue(g, vlog_param(item, j));
         exprs[nexpr++] = expr;

         if (mir_is(g->mu, expr, MIR_TYPE_REAL))
            is_real = true;
         else {
            mir_type_t expr_type = mir_get_type(g->mu, expr);
            is_signed &= mir_get_signed(g->mu, expr_type);
            width = MAX(width, mir_get_size(g->mu, expr_type));
         }
      }
   }

   mir_type_t type;
   if (is_real)
      type = mir_real_type(g->mu, -DBL_MAX, DBL_MAX);
   else
      type = mir_vec4_type(g->mu, width, is_signed);

   if (!is_signed && !is_real && mir_get_signed(g->mu, value_type)) {
      // No sign extension here
      const int size = mir_get_size(g->mu, value_type);
      mir_type_t us_type = mir_vec4_type(g->mu, size, false);
      value = mir_build_cast(g->mu, us_type, value);
   }

   value = vlog_lower_cast(g, type, value);

   for (int i = 0, nexpr = 0; i < nitems; i++) {
      vlog_node_t item = vlog_stmt(v, i);
      assert(vlog_kind(item) == V_CASE_ITEM);

      if (i == default_item)
         continue;

      mir_block_t else_bb = mir_add_block(g->mu);

      mir_value_t comb = MIR_NULL_VALUE;
      const int nparams = vlog_params(item);
      for (int j = 0; j < nparams; j++) {
         mir_value_t expr = exprs[nexpr++];
         mir_type_t expr_type = mir_get_type(g->mu, expr);
         if (!is_signed && !is_real && mir_is_vector(g->mu, expr)) {
            // No sign extension here
            const int size = mir_get_size(g->mu, expr_type);
            mir_type_t us_type = mir_vec4_type(g->mu, size, false);
            expr = mir_build_cast(g->mu, us_type, expr);
         }

         mir_value_t cast = vlog_lower_cast(g, type, expr);

         mir_value_t test;
         if (mir_is_vector(g->mu, cast)) {
            mir_value_t eq = mir_build_binary(g->mu, op, type, cast, value);
            test = mir_build_test(g->mu, eq);
         }
         else
            test = mir_build_cmp(g->mu, MIR_CMP_EQ, cast, value);

         if (mir_is_null(comb))
            comb = test;
         else
            comb = mir_build_or(g->mu, comb, test);
      }

      if (mir_is_null(comb))
         mir_build_jump(g->mu, blocks[i]);
      else
         mir_build_cond(g->mu, comb, blocks[i], else_bb);

      mir_set_cursor(g->mu, else_bb, MIR_APPEND);
   }

   mir_block_t exit_bb;
   if (default_item == -1)
      exit_bb = mir_get_cursor(g->mu, NULL);
   else {
      mir_build_jump(g->mu, blocks[default_item]);
      exit_bb = mir_add_block(g->mu);
   }

   for (int i = 0; i < nitems; i++) {
      vlog_node_t item = vlog_stmt(v, i);
      assert(vlog_kind(item) == V_CASE_ITEM);

      mir_set_cursor(g->mu, blocks[i], MIR_APPEND);
      vlog_lower_stmts(g, item, gs);

      if (!mir_block_finished(g->mu, MIR_NULL_BLOCK))
         mir_build_jump(g->mu, exit_bb);
   }

   mir_set_cursor(g->mu, exit_bb, MIR_APPEND);

   mir_comment(g->mu, "End case statement");
}

static void vlog_lower_return(vlog_gen_t *g, vlog_node_t v)
{
   mir_value_t result = MIR_NULL_VALUE;
   if (vlog_has_value(v)) {
      mir_value_t value = vlog_lower_rvalue(g, vlog_value(v));

      const type_info_t *ti = vlog_type_info(g, vlog_type(vlog_ref(v)));
      result = mir_build_cast(g->mu, ti->type, value);
   }

   if (mir_is_null(g->exit))
      mir_build_return(g->mu, result);
   else
      mir_build_jump(g->mu, g->exit);
}

static void vlog_lower_user_tcall(vlog_gen_t *g, vlog_node_t v)
{
   vlog_node_t decl = vlog_ref(v);
   ident_t func = ident_prefix(vlog_ident2(decl), vlog_ident(decl), '.');

   const int nparams = vlog_params(v);
   mir_value_t *args LOCAL =
      xmalloc_array(nparams + 1, sizeof(mir_value_t));

   SCOPED_A(mir_value_t) temps = AINIT;

   args[0] = vlog_context_for_call(g, decl);
   for (int i = 0; i < nparams; i++) {
      vlog_node_t port = vlog_port(decl, i);
      const type_info_t *ti = vlog_type_info(g, vlog_type(port));

      const v_port_kind_t dir = vlog_subkind(port);
      if (dir == V_PORT_OUTPUT || dir == V_PORT_INOUT) {
         ident_t name = ident_uniq("%s.tmp", istr(vlog_ident(port)));
         mir_value_t tmp = mir_add_var(g->mu, ti->type, ti->stamp, name, 0);

         mir_value_t init;
         if (dir == V_PORT_OUTPUT)
            init = vlog_lower_default_value(g, ti);
         else {
            mir_value_t value = vlog_lower_rvalue(g, vlog_param(v, i));
            init = vlog_lower_cast(g, ti->type, value);
         }

         mir_build_store(g->mu, tmp, init);

         args[i + 1] = tmp;
         APUSH(temps, tmp);
      }
      else {
         mir_value_t value = vlog_lower_rvalue(g, vlog_param(v, i));
         args[i + 1] = vlog_lower_cast(g, ti->type, value);
      }
   }

   mir_block_t resume_bb = mir_add_block(g->mu);
   mir_build_pcall(g->mu, func, resume_bb, args, nparams + 1);

   mir_set_cursor(g->mu, resume_bb, MIR_APPEND);
   mir_build_resume(g->mu, func);

   if (temps.count > 0) {
      for (int i = 0, pos = 0; i < nparams; i++) {
         vlog_node_t port = vlog_port(decl, i);
         if (vlog_subkind(port) != V_PORT_INPUT) {
            mir_value_t tmp = AGET(temps, pos++);
            mir_value_t value = mir_build_load(g->mu, tmp);
            vlog_assign_variable(g, vlog_param(v, i), value, NULL);
         }
      }

      ACLEAR(temps);
   }
}

static void vlog_lower_seq_block(vlog_gen_t *g, vlog_node_t v, gen_stack_t *gs)
{
   vlog_lower_locals(g, v);

   if (vlog_has_ident(v)) {
      mir_block_t exit_bb = mir_add_block(g->mu);

      block_info_t block = {
         .name    = vlog_ident(v),
         .exit_bb = exit_bb,
      };

      gen_stack_t this = vlog_push_block(gs, &block);

      vlog_lower_stmts(g, v, &this);

      if (!mir_block_finished(g->mu, MIR_NULL_BLOCK))
         mir_build_jump(g->mu, exit_bb);

      mir_set_cursor(g->mu, exit_bb, MIR_APPEND);
   }
   else
      vlog_lower_stmts(g, v, gs);
}

static void vlog_lower_stmts(vlog_gen_t *g, vlog_node_t v, gen_stack_t *gs)
{
   const int nstmts = vlog_stmts(v);
   for (int i = 0; i < nstmts; i++) {
      vlog_node_t s = vlog_stmt(v, i);
      mir_set_loc(g->mu, vlog_loc(s));

      switch (vlog_kind(s)) {
      case V_TIMING:
         vlog_lower_timing(g, s, gs);
         break;
      case V_BASSIGN:
         vlog_lower_blocking_assignment(g, s);
         break;
      case V_NBASSIGN:
         vlog_lower_non_blocking_assignment(g, s);
         break;
      case V_OP_ASSIGN:
         vlog_lower_operator_assignment(g, s);
         break;
      case V_SEQ_BLOCK:
         vlog_lower_seq_block(g, s, gs);
         break;
      case V_SYS_TCALL:
         vlog_lower_sys_tfcall(g, s);
         break;
      case V_IF:
         vlog_lower_if(g, s, gs);
         break;
      case V_FOREVER:
         vlog_lower_forever(g, s, gs);
         break;
      case V_REPEAT:
         vlog_lower_repeat(g, s, gs);
         break;
      case V_WHILE:
         vlog_lower_while(g, s, gs);
         break;
      case V_FOR_LOOP:
         vlog_lower_for_loop(g, s, gs);
         break;
      case V_CASE:
         vlog_lower_case(g, s, gs);
         break;
      case V_POSTFIX:
         vlog_lower_rvalue(g, s);
         break;
      case V_RETURN:
         vlog_lower_return(g, s);
         return;
      case V_USER_TCALL:
         vlog_lower_user_tcall(g, s);
         break;
      case V_DISABLE:
         vlog_lower_disable(g, s, gs);
         return;
      default:
         CANNOT_HANDLE(s);
      }
   }
}

static void vlog_lower_driver(vlog_gen_t *g, vlog_node_t v)
{
   if (vlog_kind(v) == V_CONCAT) {
      const int nparams = vlog_params(v);
      for (int i = 0; i < nparams; i++)
         vlog_lower_driver(g, vlog_param(v, i));
   }
   else {
      mir_type_t t_offset = mir_offset_type(g->mu);

      vlog_node_t prefix = vlog_longest_static_prefix(v);

      vlog_select_t target = vlog_lower_select(g, prefix);

      mir_value_t nets =
         mir_build_array_ref(g->mu, target.obj, target.dst_offset);

      int total_size = target.size;
      if (vlog_kind(prefix) == V_REF)
         total_size *= vlog_size(vlog_ref(prefix));

      mir_value_t count = vlog_kind(prefix) == V_REF
         ? mir_const(g->mu, t_offset, total_size) : target.count;
      mir_build_drive_signal(g->mu, nets, count);
   }
}

static void vlog_lower_always(vlog_gen_t *g, vlog_node_t v)
{
   mir_block_t start_bb = mir_add_block(g->mu);
   assert(start_bb.id == 1);

   vlog_node_t s0 = vlog_stmt(v, 0);
   if (vlog_kind(s0) == V_TIMING) {
      // Cache the event control trigger once on reset to avoid
      // regenerating it on each invocation
      vlog_node_t ctrl = vlog_value(s0);
      if (vlog_kind(ctrl) == V_EVENT_CONTROL)
         vlog_lower_trigger_var(g, ctrl);
   }

   mir_build_return(g->mu, MIR_NULL_VALUE);

   mir_set_cursor(g->mu, start_bb, MIR_APPEND);

   gen_stack_t gs = {};

   vlog_lower_stmts(g, v, &gs);

   if (!mir_block_finished(g->mu, MIR_NULL_BLOCK))
      mir_build_jump(g->mu, start_bb);
}

static void vlog_lower_initial(vlog_gen_t *g, vlog_node_t v)
{
   mir_block_t start_bb = mir_add_block(g->mu);
   assert(start_bb.id == 1);

   mir_build_return(g->mu, MIR_NULL_VALUE);

   mir_set_cursor(g->mu, start_bb, MIR_APPEND);

   gen_stack_t gs = {};

   vlog_lower_stmts(g, v, &gs);

   if (!mir_block_finished(g->mu, MIR_NULL_BLOCK))
      mir_build_return(g->mu, MIR_NULL_VALUE);
}

static void vlog_lower_final(vlog_gen_t *g, vlog_node_t v)
{
   mir_block_t start_bb = mir_add_block(g->mu);
   assert(start_bb.id == 1);

   mir_build_return(g->mu, MIR_NULL_VALUE);

   mir_set_cursor(g->mu, start_bb, MIR_APPEND);

   mir_type_t t_time = mir_time_type(g->mu);
   mir_build_sched_process(g->mu, mir_const(g->mu, t_time, TIME_HIGH));

   mir_block_t final_bb = mir_add_block(g->mu);
   mir_build_wait(g->mu, final_bb);

   mir_set_cursor(g->mu, final_bb, MIR_APPEND);

   gen_stack_t gs = {};

   vlog_lower_stmts(g, v, &gs);

   if (!mir_block_finished(g->mu, MIR_NULL_BLOCK))
      mir_build_return(g->mu, MIR_NULL_VALUE);
}

static void vlog_lower_sensitivity(vlog_gen_t *g, vlog_node_t v)
{
   const vlog_kind_t kind = vlog_kind(v);
   switch (kind) {
   case V_REF:
   case V_HIER_REF:
      {
         switch (vlog_kind(vlog_ref(v))) {
         case V_PORT_DECL:
         case V_NET_DECL:
         case V_VAR_DECL:
         case V_LOCAL_DECL:
            {
               mir_type_t t_offset = mir_offset_type(g->mu);

               vlog_select_t lvalue = vlog_lower_select(g, v);
               int total_size = lvalue.size;
               if (vlog_kind(v) == V_REF)
                  total_size *= vlog_size(vlog_ref(v));

               mir_value_t count = mir_const(g->mu, t_offset, total_size);
               mir_build_sched_event(g->mu, lvalue.obj, count);
            }
            break;
         case V_PARAM_DECL:
         case V_LOCALPARAM:
            break;
         default:
            CANNOT_HANDLE(v);
         }
      }
      break;
   case V_BIT_SELECT:
   case V_PART_SELECT:
   case V_MEMBER_REF:
      {
         vlog_node_t prefix = vlog_longest_static_prefix(v);
         if (prefix == v) {
            vlog_select_t lvalue = vlog_lower_select(g, v);

            mir_value_t nets =
               mir_build_array_ref(g->mu, lvalue.obj, lvalue.dst_offset);

            mir_build_sched_event(g->mu, nets, lvalue.count);
         }
         else if (prefix != NULL)
            vlog_lower_sensitivity(g, prefix);

         if (kind == V_BIT_SELECT) {
            const int nparams = vlog_params(v);
            for (int i = 0; i < nparams; i++)
               vlog_lower_sensitivity(g, vlog_param(v, i));
         }
         else if (kind == V_PART_SELECT)
            vlog_lower_sensitivity(g, vlog_left(v));
      }
      break;
   case V_NUMBER:
   case V_STRING:
   case V_REAL:
      break;
   case V_BINARY:
      vlog_lower_sensitivity(g, vlog_left(v));
      vlog_lower_sensitivity(g, vlog_right(v));
      break;
   case V_UNARY:
      vlog_lower_sensitivity(g, vlog_value(v));
      break;
   case V_COND_EXPR:
      vlog_lower_sensitivity(g, vlog_value(v));
      vlog_lower_sensitivity(g, vlog_left(v));
      vlog_lower_sensitivity(g, vlog_right(v));
      break;
   case V_CONCAT:
   case V_USER_FCALL:
   case V_SYS_FCALL:
      {
         const int nparams = vlog_params(v);
         for (int i = 0; i < nparams; i++)
            vlog_lower_sensitivity(g, vlog_param(v, i));
      }
      break;
   default:
      CANNOT_HANDLE(v);
   }
}

static void vlog_lower_assign_process(vlog_gen_t *g, vlog_node_t v)
{
   mir_block_t start_bb = mir_add_block(g->mu);
   assert(start_bb.id == 1);

   vlog_lower_driver(g, vlog_target(v));

   vlog_lower_sensitivity(g, vlog_value(v));

   mir_build_return(g->mu, MIR_NULL_VALUE);

   mir_set_cursor(g->mu, start_bb, MIR_APPEND);

   vlog_node_t target = vlog_target(v);

   unsigned nlvalues = 1, targetsz = 0;
   vlog_select_t lvalue1, *lvalues = &lvalue1;
   if (vlog_kind(target) == V_CONCAT) {
      nlvalues = vlog_count_lvalues(target);
      lvalues = xmalloc_array(nlvalues, sizeof(vlog_select_t));

      unsigned index = 0;
      vlog_lower_lvalues(g, target, lvalues, NULL, &index);
      assert(index == nlvalues);

      for (int i = 0; i < nlvalues; i++)
         targetsz += lvalues[i].size;
   }
   else {
      lvalue1 = vlog_lower_select(g, target);
      targetsz = lvalue1.size;
   }

   mir_type_t t_vec = mir_vec4_type(g->mu, targetsz, false);

   mir_value_t value = vlog_lower_with_context(g, vlog_value(v), t_vec);
   mir_value_t resize = vlog_lower_cast(g, t_vec, value);
   assert(mir_is_vector(g->mu, resize));

   mir_value_t tmp = MIR_NULL_VALUE;
   if (targetsz != 1) {
      mir_type_t t_elem = mir_logic_type(g->mu);
      mir_type_t t_array = mir_carray_type(g->mu, targetsz, t_elem);
      tmp = vlog_get_temp(g, t_array);
   }

   mir_type_t t_offset = mir_offset_type(g->mu);

   uint8_t strength = ST_STRONG;
   if (vlog_params(v) > 0) {
      vlog_node_t p = vlog_param(v, 0);
      assert(vlog_kind(p) == V_STRENGTH);
      strength = vlog_subkind(p);
   }

   mir_value_t unpacked = mir_build_unpack(g->mu, resize, strength, tmp);

   mir_value_t after = MIR_NULL_VALUE;
   if (vlog_has_delay(v)) {
      vlog_node_t delay = vlog_delay(v);
      assert(vlog_kind(delay) == V_DELAY_CONTROL);

      after = vlog_lower_time(g, vlog_value(delay));
   }

   for (int i = 0, offset = 0; i < nlvalues; offset += lvalues[i].size, i++) {
      mir_value_t nets = mir_build_array_ref(g->mu, lvalues[i].obj,
                                             lvalues[i].dst_offset);

      mir_value_t src = unpacked;
      if (offset > 0 || !mir_is_null(lvalues[i].src_offset)) {
         mir_value_t pos =
            mir_build_add(g->mu, t_offset, mir_const(g->mu, t_offset, offset),
                          lvalues[i].src_offset);
         src = mir_build_array_ref(g->mu, unpacked, pos);
      }

      if (mir_is_null(after))
         mir_build_put_driver(g->mu, nets, lvalues[i].count, src);
      else
         mir_build_sched_waveform(g->mu, nets, lvalues[i].count, src, after,
                                  after);
   }

   mir_build_wait(g->mu, start_bb);

   if (lvalues != &lvalue1)
      free(lvalues);
}

static void vlog_lower_net_process(vlog_gen_t *g, vlog_node_t v)
{
   mir_block_t start_bb = mir_add_block(g->mu);
   assert(start_bb.id == 1);

   int hops;
   mir_value_t var = mir_search_object(g->mu, v, &hops);
   assert(!mir_is_null(var));
   assert(hops > 0);

   const type_info_t *ti = vlog_type_info(g, vlog_type(v));

   mir_type_t t_offset = mir_offset_type(g->mu);

   {
      mir_value_t upref = mir_build_var_upref(g->mu, hops, var.id);
      mir_value_t nets = mir_build_load(g->mu, upref);
      mir_value_t count = mir_const(g->mu, t_offset, ti->size);
      mir_build_drive_signal(g->mu, nets, count);

      vlog_lower_sensitivity(g, vlog_value(v));

      mir_build_return(g->mu, MIR_NULL_VALUE);
   }

   mir_set_cursor(g->mu, start_bb, MIR_APPEND);

   {
      mir_value_t value = vlog_lower_with_context(g, vlog_value(v), ti->type);
      mir_value_t resize = vlog_lower_cast(g, ti->type, value);

      mir_value_t tmp = MIR_NULL_VALUE;
      if (ti->size != 1) {
         mir_type_t t_elem = mir_logic_type(g->mu);
         mir_type_t t_array = mir_carray_type(g->mu, ti->size, t_elem);
         tmp = vlog_get_temp(g, t_array);
      }

      mir_value_t upref = mir_build_var_upref(g->mu, hops, var.id);
      mir_value_t nets = mir_build_load(g->mu, upref);
      mir_value_t count = mir_const(g->mu, t_offset, ti->size);

      mir_value_t unpacked = mir_build_unpack(g->mu, resize, ST_STRONG, tmp);
      mir_build_put_driver(g->mu, nets, count, unpacked);

      mir_build_wait(g->mu, start_bb);
   }
}

static void vlog_lower_gate_inst(vlog_gen_t *g, vlog_node_t v)
{
   mir_block_t start_bb = mir_add_block(g->mu);
   assert(start_bb.id == 1);

   vlog_lower_driver(g, vlog_target(v));

   mir_type_t t_logic = mir_vec4_type(g->mu, 1, false);

   const int nparams = vlog_params(v);
   int first_term = 0;
   for (int i = 0; i < nparams; i++) {
      vlog_node_t p = vlog_param(v, i);
      if (vlog_kind(p) == V_STRENGTH)
         first_term = i + 1;
      else
         vlog_lower_sensitivity(g, p);
   }

   mir_build_return(g->mu, MIR_NULL_VALUE);

   mir_set_cursor(g->mu, start_bb, MIR_APPEND);

   bool negate = false;
   uint8_t strength = ST_STRONG;
   mir_value_t value = MIR_NULL_VALUE;
   const vlog_gate_kind_t kind = vlog_subkind(v);
   switch (kind) {
   case V_GATE_PULLUP:
   case V_GATE_PULLDOWN:
      strength = vlog_subkind(vlog_param(v, 0));
      value = mir_const_vec(g->mu, t_logic, kind == V_GATE_PULLUP, 0);
      break;

   case V_GATE_NAND:
   case V_GATE_NOR:
   case V_GATE_XNOR:
      negate = true;
   case V_GATE_AND:
   case V_GATE_OR:
   case V_GATE_XOR:
      {
         static const mir_vec_op_t op_map[] = {
            [V_GATE_AND] = MIR_VEC_BIT_AND,
            [V_GATE_NAND] = MIR_VEC_BIT_AND,
            [V_GATE_OR] = MIR_VEC_BIT_OR,
            [V_GATE_NOR] = MIR_VEC_BIT_OR,
            [V_GATE_XOR] = MIR_VEC_BIT_XOR,
            [V_GATE_XNOR] = MIR_VEC_BIT_XOR,
         };

         value = vlog_lower_rvalue(g, vlog_param(v, first_term));
         value = vlog_lower_cast(g, t_logic, value);

         const int nelems = nparams - first_term;
         for (int i = 1; i < nelems; i++) {
            vlog_node_t p = vlog_param(v, first_term + i);
            mir_value_t arg = vlog_lower_rvalue(g, p);
            mir_value_t cast = vlog_lower_cast(g, t_logic, arg);
            value = mir_build_binary(g->mu, op_map[kind], t_logic, value, cast);
         }

         if (negate)
            value = mir_build_unary(g->mu, MIR_VEC_BIT_NOT, t_logic, value);
      }
      break;

   case V_GATE_NOT:
      {
         mir_value_t input = vlog_lower_rvalue(g, vlog_param(v, nparams - 1));
         mir_value_t cast = vlog_lower_cast(g, t_logic, input);
         value = mir_build_unary(g->mu, MIR_VEC_BIT_NOT, t_logic, cast);
      }
      break;

   case V_GATE_BUF:
      {
         // Invert twice for correct X/Z behaviour
         mir_value_t input = vlog_lower_rvalue(g, vlog_param(v, nparams - 1));
         mir_value_t cast = vlog_lower_cast(g, t_logic, input);
         value = mir_build_unary(g->mu, MIR_VEC_BIT_NOT, t_logic, cast);
         value = mir_build_unary(g->mu, MIR_VEC_BIT_NOT, t_logic, value);
      }
      break;

   case V_GATE_NOTIF0:
   case V_GATE_NOTIF1:
      negate = true;
      // Fall-through
   case V_GATE_BUFIF0:
   case V_GATE_BUFIF1:
      {
         mir_value_t input = vlog_lower_rvalue(g, vlog_param(v, first_term));
         mir_value_t cast = vlog_lower_cast(g, t_logic, input);

         if (negate)
            cast = mir_build_unary(g->mu, MIR_VEC_BIT_NOT, t_logic, cast);

         mir_value_t enable =
            vlog_lower_rvalue(g, vlog_param(v, first_term + 1));
         mir_value_t enable_cast = vlog_lower_cast(g, t_logic, enable);

         const bool active_high =
            kind == V_GATE_BUFIF1 || kind == V_GATE_NOTIF1;
         mir_value_t active_value =
            mir_const_vec(g->mu, t_logic, active_high, 0);
         mir_value_t active_vec =
            mir_build_binary(g->mu, MIR_VEC_CASE_EQ, t_logic, enable_cast,
                             active_value);
         mir_value_t active = vlog_lower_test(g, active_vec);
         mir_value_t highz = mir_const_vec(g->mu, t_logic, 0, 1);

         value = mir_build_select(g->mu, t_logic, active, cast, highz);
      }
      break;

   default:
      CANNOT_HANDLE(v);
   }

   mir_value_t unpacked =
      mir_build_unpack(g->mu, value, strength, MIR_NULL_VALUE);

   vlog_select_t lvalue = vlog_lower_select(g, vlog_target(v));

   mir_value_t nets =
      mir_build_array_ref(g->mu, lvalue.obj, lvalue.dst_offset);

   mir_build_put_driver(g->mu, nets, lvalue.count, unpacked);
   mir_build_wait(g->mu, start_bb);
}

static void vlog_lower_port_map(vlog_gen_t *g, vlog_node_t v)
{
   vlog_node_t port = vlog_ref(v);
   assert(vlog_kind(port) == V_PORT_DECL);

   const type_info_t *ti = vlog_type_info(g, vlog_type(vlog_ref(port)));
   mir_value_t signal = mir_add_param(g->mu, ti->signal, MIR_NULL_STAMP,
                                      vlog_ident(port));

   mir_type_t t_offset = mir_offset_type(g->mu);

   mir_block_t start_bb = mir_add_block(g->mu);
   assert(start_bb.id == 1);

   {
      switch (vlog_subkind(port)) {
      case V_PORT_INPUT:
         {
            vlog_lower_sensitivity(g, vlog_value(v));

            mir_value_t count = mir_const(g->mu, t_offset, ti->size);
            mir_build_drive_signal(g->mu, signal, count);
         }
         break;
      case V_PORT_OUTPUT:
         {
            vlog_lower_driver(g, vlog_value(v));

            mir_value_t count = mir_const(g->mu, t_offset, ti->size);
            mir_build_sched_event(g->mu, signal, count);
         }
         break;
      default:
         should_not_reach_here();
      }

      mir_build_return(g->mu, MIR_NULL_VALUE);
   }

   mir_set_cursor(g->mu, start_bb, MIR_APPEND);

   unsigned nlvalues = 1, targetsz = 0;
   vlog_select_t lvalue1, *lvalues = &lvalue1;
   mir_value_t resize;

   switch(vlog_subkind(port)) {
   case V_PORT_OUTPUT:
      {
         vlog_node_t target = vlog_value(v);
         if (vlog_kind(target) == V_CONCAT) {
            nlvalues = vlog_count_lvalues(target);
            lvalues = xmalloc_array(nlvalues, sizeof(vlog_select_t));

            unsigned index = 0;
            vlog_lower_lvalues(g, target, lvalues, NULL, &index);
            assert(index == nlvalues);

            for (int i = 0; i < nlvalues; i++)
               targetsz += lvalues[i].size;
         }
         else {
            lvalue1 = vlog_lower_select(g, target);
            targetsz = lvalue1.size;
         }

         mir_type_t t_vec = mir_vec4_type(g->mu, targetsz, false);

         mir_value_t resolved = mir_build_resolved(g->mu, signal);
         mir_value_t value = mir_build_pack(g->mu, ti->type, resolved);

         assert(mir_is_vector(g->mu, value));

         resize = mir_build_cast(g->mu, t_vec, value);
      }
      break;

   case V_PORT_INPUT:
      {
         mir_value_t value =
            vlog_lower_with_context(g, vlog_value(v), ti->type);
         assert(mir_is_vector(g->mu, value));

         resize = mir_build_cast(g->mu, ti->type, value);

         mir_value_t zero = mir_const(g->mu, t_offset, 0);

         targetsz = ti->size;
         lvalue1 = (vlog_select_t){
            .obj        = signal,
            .size       = ti->size,
            .dst_offset = zero,
            .count      = mir_const(g->mu, t_offset, ti->size),
            .src_offset = zero,
            .type       = ti->type,
         };
      }
      break;

   default:
      should_not_reach_here();
   }

   mir_value_t tmp = MIR_NULL_VALUE;
   if (targetsz != 1) {
      mir_type_t t_array = mir_carray_type(g->mu, targetsz, ti->unpacked);
      tmp = vlog_get_temp(g, t_array);
   }

   mir_value_t unpacked = mir_build_unpack(g->mu, resize, ST_STRONG, tmp);

   for (int i = 0, offset = 0; i < nlvalues; offset += lvalues[i].size, i++) {
      mir_value_t nets = mir_build_array_ref(g->mu, lvalues[i].obj,
                                             lvalues[i].dst_offset);

      mir_value_t pos = mir_build_add(g->mu, t_offset,
                                      mir_const(g->mu, t_offset, offset),
                                      lvalues[i].src_offset);
      mir_value_t src = mir_build_array_ref(g->mu, unpacked, pos);

      mir_build_put_driver(g->mu, nets, lvalues[i].count, src);
   }

   if (lvalues != &lvalue1)
      free(lvalues);

   mir_build_wait(g->mu, start_bb);
}

static void vlog_lower_cleanup(vlog_gen_t *g)
{
   if (g->temps != NULL)
      ihash_free(g->temps);
}

static void vlog_lower_deferred(mir_unit_t *mu, object_t *obj)
{
   vlog_node_t v = vlog_from_object(obj);
   assert(v != NULL);

   vlog_gen_t g = {
      .mu  = mu,
      .mir = mir_get_context(mu),
   };

   switch (vlog_kind(v)) {
   case V_ALWAYS:
      vlog_lower_always(&g, v);
      break;
   case V_INITIAL:
      vlog_lower_initial(&g, v);
      break;
   case V_FINAL:
      vlog_lower_final(&g, v);
      break;
   case V_ASSIGN:
      vlog_lower_assign_process(&g, v);
      break;
   case V_NET_DECL:
      vlog_lower_net_process(&g, v);
      break;
   case V_GATE_INST:
      vlog_lower_gate_inst(&g, v);
      break;
   case V_PORT_MAP:
      vlog_lower_port_map(&g, v);
      break;
   default:
      CANNOT_HANDLE(v);
   }

   mir_optimise(mu, MIR_PASS_O1);

   vlog_lower_cleanup(&g);
}

static void vlog_lower_net_decl(vlog_gen_t *g, vlog_node_t v, tree_t wrap,
                                mir_value_t resfn)
{
   mir_type_t t_net_value = mir_int_type(g->mu, 0, 255);
   mir_type_t t_net_signal = mir_signal_type(g->mu, t_net_value);
   mir_type_t t_offset = mir_offset_type(g->mu);

   assert(wrap != NULL);

   const type_info_t *ti = vlog_type_info(g, vlog_type(v));
   const int total_size = ti->size * vlog_size(v);

   mir_value_t value = mir_const(g->mu, t_net_value, LOGIC_Z);
   mir_value_t count = mir_const(g->mu, t_offset, total_size);
   mir_value_t size = mir_const(g->mu, t_offset, 1);
   mir_value_t flags = mir_const(g->mu, t_offset, 0);
   mir_value_t locus = mir_build_debug_locus(g->mu, tree_to_object(wrap));

   mir_value_t signal = mir_build_init_signal(g->mu, t_net_value, count, size,
                                              value, flags, locus,
                                              MIR_NULL_VALUE);

   mir_build_resolve_signal(g->mu, signal, resfn);

   mir_value_t var = mir_add_var(g->mu, t_net_signal, MIR_NULL_STAMP,
                                 vlog_ident(v), MIR_VAR_SIGNAL);
   mir_build_store(g->mu, var, signal);

   mir_put_object(g->mu, v, var);

   if (vlog_has_value(v)) {
      ident_t parent = mir_get_name(g->mu, MIR_NULL_VALUE);
      ident_t sym = ident_sprintf("%s.%s#assign", istr(parent),
                                  istr(vlog_ident(v)));
      mir_defer(g->mir, sym, parent, MIR_UNIT_PROCESS,
                vlog_lower_deferred, vlog_to_object(v));

      mir_value_t self = mir_build_context_upref(g->mu, 0);
      mir_value_t args[] = { self };
      mir_value_t closure = mir_build_closure(g->mu, sym, t_offset, args, 1);
      mir_value_t locus = mir_build_debug_locus(g->mu, tree_to_object(wrap));

      mir_build_process_init(g->mu, closure, locus);
   }
}

static void vlog_lower_var_decl(vlog_gen_t *g, vlog_node_t v, tree_t wrap)
{
   const type_info_t *ti = vlog_type_info(g, vlog_type(v));

   if (mir_get_class(g->mu, ti->type) == MIR_TYPE_CONTEXT) {
      // Class variable
      mir_value_t null = mir_build_null(g->mu, ti->type);
      mir_value_t var = mir_add_var(g->mu, ti->type, MIR_NULL_STAMP,
                                    vlog_ident(v), 0);
      mir_build_store(g->mu, var, null);

      mir_put_object(g->mu, v, var);
      return;
   }
   else if (vlog_is_unsized(v)) {
      mir_type_t t_uarray = mir_uarray_type(g->mu, vlog_ranges(v), ti->type);
      mir_value_t var = mir_add_var(g->mu, t_uarray, MIR_NULL_STAMP,
                                    vlog_ident(v), 0);

      mir_type_t t_pointer = mir_pointer_type(g->mu, ti->type);
      mir_value_t null = mir_build_null(g->mu, t_pointer);

      mir_type_t t_offset = mir_offset_type(g->mu);
      mir_type_t t_bool = mir_bool_type(g->mu);

      mir_value_t left = mir_const(g->mu, t_offset, 0);
      mir_value_t right = mir_const(g->mu, t_offset, -1);
      mir_value_t dir = mir_const(g->mu, t_bool, RANGE_TO);

      mir_dim_t dims[1] = { { left, right, dir } };
      mir_value_t init = mir_build_wrap(g->mu, null, dims, 1);
      mir_build_store(g->mu, var, init);

      mir_put_object(g->mu, v, var);
      return;
   }

   mir_type_t t_offset = mir_offset_type(g->mu);

   const int total_size = ti->size * vlog_size(v);

   assert(wrap != NULL);

   mir_value_t value;
   if (vlog_has_value(v)) {
      mir_value_t tmp = MIR_NULL_VALUE;
      if (ti->size > 1) {
         mir_type_t t_elem = mir_logic_type(g->mu);
         mir_type_t t_array = mir_carray_type(g->mu, total_size, t_elem);
         tmp = vlog_get_temp(g, t_array);
      }

      mir_value_t packed = vlog_lower_rvalue(g, vlog_value(v));
      mir_value_t cast = vlog_lower_cast(g, ti->type, packed);
      if (mir_get_class(g->mu, ti->unpacked) == MIR_TYPE_REAL)
         value = cast;
      else
         value = mir_build_unpack(g->mu, cast, 0, tmp);
   }
   else if (mir_get_class(g->mu, ti->unpacked) == MIR_TYPE_REAL)
      value = mir_const_real(g->mu, ti->unpacked, 0.0);
   else
      value = mir_const(g->mu, ti->unpacked, LOGIC_X);

   mir_value_t count = mir_const(g->mu, t_offset, total_size);
   mir_value_t size = mir_const(g->mu, t_offset, ti->elemsz);
   mir_value_t flags = mir_const(g->mu, t_offset, 0);
   mir_value_t locus = mir_build_debug_locus(g->mu, tree_to_object(wrap));

   mir_value_t signal = mir_build_init_signal(g->mu, ti->unpacked, count, size,
                                              value, flags, locus,
                                              MIR_NULL_VALUE);

   mir_value_t var = mir_add_var(g->mu, ti->signal, MIR_NULL_STAMP,
                                 vlog_ident(v), MIR_VAR_SIGNAL);
   mir_build_store(g->mu, var, signal);

   mir_put_object(g->mu, v, var);
}

static void vlog_lower_port_decl(vlog_gen_t *g, vlog_node_t v)
{
   const type_info_t *ti = vlog_type_info(g, vlog_type(v));

   mir_type_t type;
   vlog_node_t d = vlog_ref(v);
   if (vlog_kind(d) == V_NET_DECL) {
      mir_type_t t_net_value = mir_int_type(g->mu, 0, 255);
      type = mir_signal_type(g->mu, t_net_value);
   }
   else
      type = ti->signal;

   mir_value_t p = mir_add_param(g->mu, type, MIR_NULL_STAMP, vlog_ident(v));

   mir_value_t var = mir_add_var(g->mu, type, MIR_NULL_STAMP,
                                 vlog_ident(v), MIR_VAR_SIGNAL);
   mir_build_store(g->mu, var, p);

   mir_put_object(g->mu, v, var);
   mir_put_object(g->mu, d, var);
}

static void vlog_lower_genvar_decl(vlog_gen_t *g, vlog_node_t v)
{
   const type_info_t *ti = vlog_type_info(g, vlog_type(v));

   mir_value_t var = mir_add_var(g->mu, ti->type, MIR_NULL_STAMP,
                                 vlog_ident(v), 0);
   mir_build_store(g->mu, var, mir_const_vec(g->mu, ti->type, ~0, ~0));

   mir_put_object(g->mu, v, var);
}

static void vlog_lower_locals(vlog_gen_t *g, vlog_node_t v)
{
   const int ndecls = vlog_decls(v);
   for (int i = 0; i < ndecls; i++) {
      vlog_node_t d = vlog_decl(v, i);
      switch (vlog_kind(d)) {
      case V_LOCAL_DECL:
      case V_VAR_DECL:
         {
            const type_info_t *ti = vlog_type_info(g, vlog_type(d));

            const int nelems = vlog_size(d);
            mir_type_t type = ti->type;
            if (nelems > 1)
               type = mir_carray_type(g->mu, nelems, ti->type);

            mir_value_t var = mir_add_var(g->mu, type, ti->stamp,
                                          vlog_ident(d), 0);
            mir_put_object(g->mu, d, var);

            if (vlog_has_value(d)) {
               assert(nelems == 1);  // TODO: unpacked array initialisation
               mir_value_t value = vlog_lower_rvalue(g, vlog_value(d));
               mir_value_t init = vlog_lower_cast(g, ti->type, value);
               mir_build_store(g->mu, var, init);
            }
            else {
               mir_value_t init = vlog_lower_default_value(g, ti);

               if (nelems > 1) {
                  mir_type_t t_offset = mir_offset_type(g->mu);
                  mir_value_t count = mir_const(g->mu, t_offset, nelems);
                  mir_build_set(g->mu, var, init, count);
               }
               else
                  mir_build_store(g->mu, var, init);
            }
         }
         break;
      default:
         CANNOT_HANDLE(d);
      }
   }
}

static void vlog_lower_func_decl(mir_unit_t *mu, object_t *obj)
{
   vlog_node_t v = vlog_from_object(obj);
   assert(vlog_kind(v) == V_FUNC_DECL);

   vlog_gen_t g = {
      .mu  = mu,
      .mir = mir_get_context(mu),
   };

   const type_info_t *ti = vlog_type_info(&g, vlog_type(v));
   mir_set_result(mu, ti->type);

   ident_t parent = mir_get_parent(mu);
   if (parent == NULL)
      g.constfunc = true;
   else {
      mir_type_t t_context = mir_context_type(mu, mir_get_parent(mu));
      mir_add_param(mu, t_context, MIR_NULL_STAMP, ident_new("context"));
   }

   const int nports = vlog_ports(v);
   for (int i = 0; i < nports; i++) {
      vlog_node_t port = vlog_port(v, i);
      const type_info_t *pti = vlog_type_info(&g, vlog_type(port));
      mir_value_t value = mir_add_param(mu, pti->type, pti->stamp,
                                        vlog_ident(port));
      mir_put_object(mu, port, value);
   }

   mir_value_t result = mir_add_var(mu, ti->type, ti->stamp, vlog_ident(v), 0);
   mir_put_object(mu, v, result);

   mir_build_store(mu, result, vlog_lower_default_value(&g, ti));

   gen_stack_t gs = {};

   vlog_lower_locals(&g, v);
   vlog_lower_stmts(&g, v, &gs);

   if (!mir_block_finished(mu, MIR_NULL_BLOCK))
      mir_build_return(mu, mir_build_load(mu, result));

   mir_optimise(mu, MIR_PASS_O1);
   vlog_lower_cleanup(&g);
}

static void vlog_lower_task_decl(mir_unit_t *mu, object_t *obj)
{
   vlog_node_t v = vlog_from_object(obj);
   assert(vlog_kind(v) == V_TASK_DECL);

   vlog_gen_t g = {
      .mu   = mu,
      .mir  = mir_get_context(mu),
      .exit = mir_add_block(mu),
   };

   mir_type_t t_context = mir_context_type(mu, mir_get_parent(mu));
   mir_add_param(mu, t_context, MIR_NULL_STAMP, ident_new("context"));

   const int nports = vlog_ports(v);
   for (int i = 0; i < nports; i++) {
      vlog_node_t port = vlog_port(v, i);
      const type_info_t *pti = vlog_type_info(&g, vlog_type(port));
      ident_t name = vlog_ident(port);

      mir_value_t local = mir_add_var(mu, pti->type, pti->stamp, name, 0);
      mir_put_object(mu, port, local);

      if (vlog_subkind(port) == V_PORT_INPUT) {
         mir_value_t param = mir_add_param(mu, pti->type, pti->stamp, name);
         mir_build_store(mu, local, param);
      }
      else {
         mir_type_t t_pointer = mir_pointer_type(mu, pti->type);
         mir_value_t param = mir_add_param(mu, t_pointer, pti->stamp, name);

         mir_value_t init = mir_build_load(mu, param);
         mir_build_store(mu, local, init);
      }
   }

   gen_stack_t gs = {};

   vlog_lower_locals(&g, v);
   vlog_lower_stmts(&g, v, &gs);

   if (!mir_block_finished(mu, MIR_NULL_BLOCK))
      mir_build_jump(mu, g.exit);

   mir_set_cursor(mu, g.exit, MIR_APPEND);

   for (int i = 0; i < nports; i++) {
      vlog_node_t port = vlog_port(v, i);
      if (vlog_subkind(port) == V_PORT_INPUT)
         continue;

      int hops;
      mir_value_t local = mir_search_object(mu, port, &hops);
      assert(!mir_is_null(local));
      assert(hops == 0);

      mir_value_t param = mir_get_param(mu, i + 1);
      mir_value_t result = mir_build_load(mu, local);
      mir_build_store(mu, param, result);
   }


   mir_build_return(mu, MIR_NULL_VALUE);

   mir_optimise(mu, MIR_PASS_O1);
   vlog_lower_cleanup(&g);
}

static void vlog_lower_class_decl(mir_unit_t *mu, object_t *obj)
{
   vlog_node_t v = vlog_from_object(obj);
   assert(vlog_kind(v) == V_CLASS_DECL);

   vlog_gen_t g = {
      .mu  = mu,
      .mir = mir_get_context(mu),
   };

   mir_type_t t_context = mir_context_type(mu, mir_get_parent(mu));
   mir_add_param(mu, t_context, MIR_NULL_STAMP, ident_new("context"));

   vlog_lower_locals(&g, v);

   if (!mir_block_finished(mu, MIR_NULL_BLOCK))
      mir_build_return(mu, MIR_NULL_VALUE);

   mir_optimise(mu, MIR_PASS_O0);
   vlog_lower_cleanup(&g);
}

static mir_type_t vlog_lower_vhdl_type(mir_unit_t *mu, type_t type)
{
   if (type_eq(type, ieee_type(IEEE_STD_ULOGIC)))
      return mir_int_type(mu, 0, 8);
   else if (type_eq(type, verilog_type(VERILOG_NET_VALUE)))
      return mir_int_type(mu, 0, 255);
   else if (type_eq(type, verilog_type(VERILOG_LOGIC)))
      return mir_int_type(mu, 0, 3);

   fatal_trace("cannot lower VHDL type %s", type_pp(type));
}

static void vlog_lower_converter(mir_unit_t *mu, tree_t cf)
{
   type_t src_type = tree_type(tree_value(cf));
   type_t src_elem = type_elem_recur(src_type);
   mir_type_t t_src_elem = vlog_lower_vhdl_type(mu, src_elem);
   mir_type_t t_src_elem_signal = mir_signal_type(mu, t_src_elem);

   mir_type_t t_src_signal = t_src_elem_signal;
   if (type_is_array(src_type))
      t_src_signal = mir_uarray_type(mu, 1, t_src_elem_signal);

   mir_type_t t_offset = mir_offset_type(mu);

   type_t dst_type = tree_type(cf);
   type_t dst_elem = type_elem_recur(dst_type);
   mir_type_t t_dst_elem = vlog_lower_vhdl_type(mu, dst_elem);
   mir_type_t t_dst_elem_signal = mir_signal_type(mu, t_dst_elem);

   mir_type_t t_dst_signal = t_dst_elem_signal, t_dst = t_dst_elem;
   if (type_is_array(dst_type)) {
      t_dst = mir_uarray_type(mu, 1, t_dst_elem);
      t_dst_signal = mir_uarray_type(mu, 1, t_dst_elem_signal);
   }

   mir_value_t in = mir_add_param(mu, t_src_signal, MIR_NULL_STAMP,
                                  ident_new("src"));
   mir_value_t out = mir_add_param(mu, t_dst_signal, MIR_NULL_STAMP,
                                   ident_new("dst"));

   mir_block_t start_bb = mir_add_block(mu);
   assert(start_bb.id == 1);

   {
      mir_value_t out_nets = out, out_count = mir_const(mu, t_offset, 1);
      if (mir_is(mu, out, MIR_TYPE_UARRAY)) {
         out_nets = mir_build_unwrap(mu, out);
         out_count = mir_build_uarray_len(mu, out, 0);
      }

      mir_build_drive_signal(mu, out_nets, out_count);

      mir_value_t in_nets = in, in_count = mir_const(mu, t_offset, 1);
      if (mir_is(mu, in, MIR_TYPE_UARRAY)) {
         in_nets = mir_build_unwrap(mu, in);
         in_count = mir_build_uarray_len(mu, in, 0);
      }

      mir_build_sched_event(mu, in_nets, in_count);

      mir_build_return(mu, MIR_NULL_VALUE);
   }

   mir_set_cursor(mu, start_bb, MIR_APPEND);

   tree_t decl = tree_ref(cf);
   assert(tree_kind(decl) == T_FUNC_DECL);
   assert(type_eq(type_result(tree_type(decl)), tree_type(cf)));

   ident_t func = tree_ident2(decl);

   mir_value_t pkg = mir_build_link_package(mu, well_known(W_NVC_VERILOG));

   mir_value_t count = MIR_NULL_VALUE;
   if (mir_is(mu, in, MIR_TYPE_UARRAY)) {
      count = mir_build_uarray_len(mu, in, 0);
      in = mir_build_unwrap(mu, in);
   }

   mir_value_t resolved = mir_build_resolved(mu, in);

   mir_value_t arg;
   if (!mir_is_null(count)) {
      mir_dim_t dims[] = {
         { .left  = mir_const(mu, t_offset, 1),
           .right = count,
           .dir   = mir_const(mu, mir_bool_type(mu), RANGE_TO),
         }
      };
      arg = mir_build_wrap(mu, resolved, dims, 1);
   }
   else {
      arg = mir_build_load(mu, resolved);
      count = mir_const(mu, t_offset, 1);
   }

   mir_value_t args[] = { pkg, arg };

   mir_value_t result = mir_build_fcall(mu, func, t_dst, MIR_NULL_STAMP,
                                        args, ARRAY_LEN(args));

   if (mir_is(mu, result, MIR_TYPE_UARRAY))
      result = mir_build_unwrap(mu, result);

   if (mir_is(mu, out, MIR_TYPE_UARRAY))
      out = mir_build_unwrap(mu, out);

   mir_build_put_driver(mu, out, count, result);

   mir_build_wait(mu, start_bb);

   mir_optimise(mu, MIR_PASS_O0);
}

static void vlog_lower_convert_in(mir_unit_t *mu, object_t *obj)
{
   tree_t map = tree_from_object(obj);
   assert(tree_kind(map) == T_PARAM);

   tree_t cf = tree_value(map);
   assert(tree_kind(cf) == T_CONV_FUNC);

   vlog_lower_converter(mu, cf);
}

static void vlog_lower_convert_out(mir_unit_t *mu, object_t *obj)
{
   tree_t map = tree_from_object(obj);
   assert(tree_kind(map) == T_PARAM);

   tree_t cf = tree_name(map);
   assert(tree_kind(cf) == T_CONV_FUNC);

   vlog_lower_converter(mu, cf);
}

void vlog_lower_instance(mir_context_t *mc, vlog_node_t body, ident_t parent,
                         tree_t trans)
{
   assert(vlog_kind(body) == V_INST_BODY);

   mir_shape_t *shape = NULL;
   if (parent != NULL)
      shape = mir_get_shape(mc, parent);

   ident_t qual = vlog_ident(body);
   mir_unit_t *mu = mir_unit_new(mc, qual, vlog_to_object(body),
                                 MIR_UNIT_INSTANCE, shape);

   hash_t *map = hash_new(16);

   const int vhdl_ndecls = tree_decls(trans);
   const int vlog_ndecls = vlog_decls(body);

   for (int i = 0; i < vhdl_ndecls; i++) {
      tree_t t = tree_decl(trans, i);
      if (tree_kind(t) == T_VERILOG)
         hash_put(map, tree_vlog(t), t);
   }

   ident_t pkg_name = well_known(W_NVC_VERILOG);
   mir_value_t pkg = mir_build_package_init(mu, pkg_name, MIR_NULL_VALUE);

   mir_type_t t_net_value = mir_int_type(mu, 0, 255);
   mir_type_t t_resolution = mir_resolution_type(mu, t_net_value);

   ident_t var_name = ident_new("NVC.VERILOG.T_WIRE$resolution");
   mir_value_t resfn = mir_build_link_var(mu, pkg, var_name, t_resolution);

   vlog_gen_t g = {
      .mu  = mu,
      .mir = mc,
   };

   const int nports = vlog_ports(body);
   for (int i = 0; i < nports; i++) {
      vlog_node_t d = vlog_ref(vlog_port(body, i));
      assert(vlog_kind(d) == V_PORT_DECL);

      vlog_lower_port_decl(&g, d);
   }

   for (int i = 0, hops; i < vlog_ndecls; i++) {
      vlog_node_t d = vlog_decl(body, i);

      switch (vlog_kind(d)) {
      case V_PORT_DECL:
         break;   // Translated above
      case V_NET_DECL:
         if (mir_is_null(mir_search_object(mu, d, &hops)))
            vlog_lower_net_decl(&g, d, hash_get(map, d), resfn);
         else
            assert(hops == 0); // Port
         break;
      case V_VAR_DECL:
         if (mir_is_null(mir_search_object(mu, d, &hops)))
            vlog_lower_var_decl(&g, d, hash_get(map, d));
         else
            assert(hops == 0); // Port
         break;
      case V_GENVAR_DECL:
         vlog_lower_genvar_decl(&g, d);
         break;
      case V_LOCALPARAM:
         break;  // Always inlined for now
      case V_FUNC_DECL:
         mir_defer(mc, ident_prefix(vlog_ident2(d), vlog_ident(d), '.'), qual,
                   MIR_UNIT_FUNCTION, vlog_lower_func_decl, vlog_to_object(d));
         break;
      case V_TASK_DECL:
         mir_defer(mc, ident_prefix(vlog_ident2(d), vlog_ident(d), '.'), qual,
                   MIR_UNIT_PROCEDURE, vlog_lower_task_decl, vlog_to_object(d));
         break;
      case V_CLASS_DECL:
         mir_defer(mc, ident_prefix(vlog_ident2(d), vlog_ident(d), '.'), qual,
                   MIR_UNIT_PROTECTED, vlog_lower_class_decl,
                   vlog_to_object(d));
         break;
      case V_TYPE_DECL:
         break;
      default:
         CANNOT_HANDLE(d);
      }
   }

   mir_value_t self = mir_build_context_upref(mu, 0);

   const int nstmts = tree_stmts(trans);
   for (int i = 0; i < nstmts; i++) {
      tree_t wrap = tree_stmt(trans, i);
      if (tree_kind(wrap) != T_VERILOG)
         continue;

      vlog_node_t s = tree_vlog(wrap);

      switch (vlog_kind(s)) {
      case V_FINAL:
      case V_ASSIGN:
      case V_INITIAL:
      case V_ALWAYS:
      case V_GATE_INST:
         {
            ident_t sym = ident_prefix(qual, vlog_ident(s), '.');
            mir_defer(mc, sym, qual, MIR_UNIT_PROCESS,
                      vlog_lower_deferred, vlog_to_object(s));

            mir_type_t t_offset = mir_offset_type(mu);
            mir_value_t args[] = { self };
            mir_value_t closure =
               mir_build_closure(mu, sym, t_offset, args, 1);
            mir_value_t locus = mir_build_debug_locus(mu, tree_to_object(wrap));

            mir_build_process_init(mu, closure, locus);
         }
         break;
      case V_UDP_TABLE:
         {
            ident_t sym = ident_prefix(qual, vlog_ident(s), '.');
            mir_defer(mc, sym, qual, MIR_UNIT_PROCESS,
                      vlog_lower_udp, vlog_to_object(body));

            mir_type_t t_offset = mir_offset_type(mu);
            mir_value_t args[] = { self };
            mir_value_t closure =
               mir_build_closure(mu, sym, t_offset, args, 1);
            mir_value_t locus = mir_build_debug_locus(mu, tree_to_object(wrap));

            mir_build_process_init(mu, closure, locus);
         }
         break;
      default:
         break;
      }
   }

   mir_build_return(mu, MIR_NULL_VALUE);

   vlog_lower_cleanup(&g);

   hash_free(map);

   mir_optimise(mu, MIR_PASS_O1);
   mir_put_unit(mc, mu);
}

void vlog_lower_block(mir_context_t *mc, ident_t parent, tree_t b)
{
   tree_t hier = tree_decl(b, 0);
   assert(tree_kind(hier) == T_HIER);

   mir_shape_t *shape = NULL;
   if (parent != NULL)
      shape = mir_get_shape(mc, parent);

   ident_t qual = tree_ident(hier);
   mir_unit_t *mu = mir_unit_new(mc, qual, tree_to_object(b),
                                 MIR_UNIT_FUNCTION, shape);

   mir_value_t context = MIR_NULL_VALUE;
   if (shape != NULL) {
      mir_type_t t_context = mir_context_type(mu, parent);
      context = mir_add_param(mu, t_context, MIR_NULL_STAMP,
                              ident_new("context"));
   }

   tree_t wrap = tree_ref(hier);
   assert(tree_kind(wrap) == T_VERILOG);

   vlog_node_t body = tree_vlog(wrap);
   const vlog_kind_t body_kind = vlog_kind(body);
   assert(body_kind == V_INST_BODY || body_kind == V_GEN_BLOCK);

   vlog_gen_t g = {
      .mu  = mu,
      .mir = mc,
   };

   hash_t *map = hash_new(16);

   const int vhdl_ndecls = tree_decls(b);
   const int vlog_ndecls = vlog_decls(body);

   for (int i = 1, pos = 0; i < vhdl_ndecls; i++) {
      tree_t t = tree_decl(b, i);
      if (vlog_kind(tree_vlog(t)) == V_PORT_MAP)
         continue;

      ident_t id = tree_ident(t);
      for (; pos < vlog_ndecls; pos++) {
         vlog_node_t v = vlog_decl(body, pos);
         if (vlog_kind(v) == V_PORT_DECL)
            continue;
         else if (vlog_ident(v) == id) {
            hash_put(map, v, t);
            break;
         }
      }

      if (pos == vlog_ndecls)
         fatal_trace("missing VHDL signal for %s", istr(id));
   }

   const int vhdl_nports = tree_ports(b);
   const int vlog_nports = body_kind == V_INST_BODY ? vlog_ports(body) : 0;

   for (int i = 0; i < vhdl_nports; i++)
      hash_put(map, vlog_ref(vlog_ref(vlog_port(body, i))), tree_port(b, i));

   ident_t pkg_name = well_known(W_NVC_VERILOG);
   mir_value_t pkg = mir_build_package_init(mu, pkg_name, MIR_NULL_VALUE);

   mir_type_t t_net_value = mir_int_type(mu, 0, 255);
   mir_type_t t_resolution = mir_resolution_type(mu, t_net_value);
   mir_type_t t_offset = mir_offset_type(mu);

   ident_t var_name = ident_new("NVC.VERILOG.T_WIRE$resolution");
   mir_value_t resfn = mir_build_link_var(mu, pkg, var_name, t_resolution);

   for (int i = 1; i < vhdl_ndecls; i++) {
      tree_t t = tree_decl(b, i);
      assert(tree_kind(t) == T_VERILOG);

      vlog_node_t v = tree_vlog(t);
      if (vlog_kind(v) != V_PORT_MAP)
         continue;

      vlog_node_t port = vlog_ref(v);
      assert(vlog_kind(port) == V_PORT_DECL);

      vlog_node_t value = vlog_value(v);
      switch (vlog_kind(value)) {
      case V_REF:
      case V_BIT_SELECT:
      case V_PART_SELECT:
         {
            vlog_select_t lvalue = vlog_lower_select(&g, vlog_value(v));
            const type_info_t *ti = vlog_type_info(&g, vlog_type(port));
            if (!mir_is_signal(mu, lvalue.obj))
               break;    // Port tied to constant
            else if (lvalue.size != ti->size)
               break;

            // Cannot collapse port if select not in range
            int64_t count_const;
            if (!mir_get_const(mu, lvalue.count, &count_const))
               break;
            else if (count_const != lvalue.size)
               break;

            mir_value_t nets =
               mir_build_array_ref(mu, lvalue.obj, lvalue.dst_offset);

            mir_put_object(mu, port, nets);
         }
         continue;
      default:
         break;
      }

      vlog_node_t d = vlog_ref(port);
      switch (vlog_kind(d)) {
      case V_NET_DECL:
         vlog_lower_net_decl(&g, d, hash_get(map, d), resfn);
         break;
      case V_VAR_DECL:
         vlog_lower_var_decl(&g, d, hash_get(map, d));
         break;
      default:
         should_not_reach_here();
      }

      int hops;
      mir_value_t var = mir_search_object(mu, d, &hops);
      assert(!mir_is_null(var));
      assert(hops == 0);

      mir_value_t nets = mir_build_load(mu, var);
      mir_put_object(mu, port, nets);

      ident_t sym = ident_prefix(qual, vlog_ident(port), '@');
      mir_defer(mc, sym, parent, MIR_UNIT_PROCESS,
                vlog_lower_deferred, vlog_to_object(v));

      mir_value_t args[] = { context, nets };
      mir_value_t closure = mir_build_closure(mu, sym, MIR_NULL_TYPE,
                                              args, ARRAY_LEN(args));
      mir_value_t locus = mir_build_debug_locus(mu, tree_to_object(t));

      mir_build_process_init(mu, closure, locus);
   }

   for (int i = 0; i < vlog_nports; i++) {
      vlog_node_t ref = vlog_port(body, i);
      assert(vlog_kind(ref) == V_REF);

      vlog_node_t port = vlog_ref(ref);
      assert(vlog_kind(port) == V_PORT_DECL);

      vlog_node_t d = vlog_ref(port);

      int hops;
      mir_value_t var = mir_search_object(mu, port, &hops);
      if (mir_is_null(var)) {
         switch (vlog_kind(d)) {
         case V_NET_DECL:
            vlog_lower_net_decl(&g, d, hash_get(map, d), resfn);
            break;
         case V_VAR_DECL:
            vlog_lower_var_decl(&g, d, hash_get(map, d));
            break;
         default:
            should_not_reach_here();
         }

         int hops;
         mir_value_t var = mir_search_object(mu, d, &hops);
         assert(!mir_is_null(var));
         assert(hops == 0);

         mir_value_t nets = mir_build_load(mu, var);
         mir_put_object(mu, port, nets);
      }
      else if (vlog_kind(d) == V_VAR_DECL && vlog_has_value(d)) {
         const type_info_t *ti = vlog_type_info(&g, vlog_type(d));
         vlog_node_t value = vlog_value(d);
         mir_value_t init = vlog_lower_with_context(&g, value, ti->type);

         if (mir_is_vector(mu, init)) {
            mir_value_t tmp = MIR_NULL_VALUE;
            if (ti->size > 1) {
               mir_type_t t_array = mir_carray_type(mu, ti->size, ti->unpacked);
               tmp = vlog_get_temp(&g, t_array);
            }

            mir_value_t resize = mir_build_cast(mu, ti->type, init);
            init = mir_build_unpack(mu, resize, 0, tmp);
         }

         mir_value_t count = mir_const(mu, t_offset, ti->size);
         mir_build_map_const(mu, init, var, count);
      }
   }

   mir_value_t *args LOCAL =
      xmalloc_array(vlog_nports + 1, sizeof(mir_value_t));

   if (mir_is_null(context))
      args[0] = mir_build_null(mu, mir_context_type(mu, qual));
   else
      args[0] = context;

   for (int i = 0; i < vlog_nports; i++) {
      vlog_node_t ref = vlog_port(body, i);
      assert(vlog_kind(ref) == V_REF);

      vlog_node_t port = vlog_ref(ref);
      assert(vlog_kind(port) == V_PORT_DECL);

      int hops;
      mir_value_t nets = mir_search_object(mu, port, &hops);
      if (mir_is_null(nets)) {
         mir_dump(mu);
         fatal_trace("missing variable for port %pi", vlog_ident(port));
      }
      assert(hops == 0);

      args[i + 1] = nets;
   }

   mir_value_t inst = mir_build_instance_init(mu, vlog_ident(body),
                                              args, vlog_nports + 1);

   mir_set_result(mu, mir_get_type(mu, inst));

   mir_type_t t_bool = mir_bool_type(mu);

   for (int i = 0; i < vlog_nports; i++) {
      vlog_node_t ref = vlog_port(body, i);
      assert(vlog_kind(ref) == V_REF);

      vlog_node_t port = vlog_ref(ref);
      assert(vlog_kind(port) == V_PORT_DECL);

      if (i >= vhdl_nports)
         continue;   // Port conversion only for mixed instantiation

      int hops;
      mir_value_t src = mir_search_object(mu, port, &hops);
      assert(!mir_is_null(src));
      assert(hops == 0);
      assert(src.tag == MIR_TAG_NODE);

      mir_value_t count = mir_const(mu, t_offset, vlog_size(vlog_type(port)));

      tree_t map = tree_param(b, i);
      tree_t value = tree_value(map), actual = value;

      mir_value_t src_nets = src, src_count = count;

      if (tree_kind(value) == T_CONV_FUNC)
         actual = tree_value(value);

      assert(tree_kind(actual) == T_REF);

      tree_t vhdl_port = tree_ref(actual);
      assert(tree_kind(vhdl_port) == T_PORT_DECL);

      int nth = mir_find_slot(shape, tree_ident(vhdl_port));
      assert(nth >= 0);

      mir_value_t upref = mir_build_var_upref(mu, 1, nth);
      mir_value_t dst = mir_build_load(mu, upref), dst_nets = dst;

      type_t vhdl_type = tree_type(vhdl_port);
      assert(dimension_of(vhdl_type) == 1);

      mir_value_t dst_count;
      if (mir_is(mu, dst, MIR_TYPE_UARRAY)) {
         dst_count = mir_build_uarray_len(mu, dst, 0);
         dst_nets = mir_build_unwrap(mu, dst);
      }
      else if (type_is_array(vhdl_type)) {
         int64_t cval;
         if (!folded_length(range_of(vhdl_type, 0), &cval))
            should_not_reach_here();

         dst_count = mir_const(mu, t_offset, cval);

         mir_dim_t dims[] = {
            { .left = mir_const(mu, t_offset, 1),
              .right = dst_count,
              .dir = mir_const(mu, t_bool, RANGE_TO)
            },
         };
         dst = mir_build_wrap(mu, dst_nets, dims, 1);
      }
      else if (type_is_scalar(vhdl_type))
         dst_count = mir_const(mu, t_offset, 1);
      else
         should_not_reach_here();

      type_t vlog_type = tree_type(tree_port(b, i));
      assert(dimension_of(vlog_type) == 1);

      if (type_is_array(vlog_type)) {
         mir_dim_t dims[] = {
            { .left = mir_const(mu, t_offset, 1),
              .right = src_count,
              .dir = mir_const(mu, t_bool, RANGE_TO)
            },
         };
         src = mir_build_wrap(mu, src_nets, dims, 1);
      }

      if (tree_kind(value) == T_CONV_FUNC) {
         ident_t sym = ident_sprintf("%s.%s$verilog_convert_in",
                                     istr(qual), istr(vlog_ident(port)));
         mir_defer(mc, sym, vlog_ident(body), MIR_UNIT_PROCESS,
                   vlog_lower_convert_in, tree_to_object(map));

         mir_value_t args[] = { inst, dst, src };
         mir_value_t closure = mir_build_closure(mu, sym, t_offset,
                                                 args, ARRAY_LEN(args));
         mir_value_t locus = mir_build_debug_locus(mu, tree_to_object(map));
         mir_build_process_init(mu, closure, locus);
      }

      if (tree_subkind(map) == P_NAMED) {
         tree_t name = tree_name(map);
         if (tree_kind(name) == T_CONV_FUNC) {
            ident_t sym = ident_sprintf("%s.%s$verilog_convert_out",
                                        istr(qual), istr(vlog_ident(port)));
            mir_defer(mc, sym, vlog_ident(body), MIR_UNIT_PROCESS,
                      vlog_lower_convert_out, tree_to_object(map));

            mir_value_t args[] = { inst, src, dst };
            mir_value_t closure = mir_build_closure(mu, sym, t_offset,
                                                    args, ARRAY_LEN(args));
            mir_value_t locus = mir_build_debug_locus(mu, tree_to_object(map));
            mir_build_process_init(mu, closure, locus);
         }
      }

      mir_value_t locus = mir_build_debug_locus(mu, tree_to_object(map));
      mir_build_length_check(mu, src_count, dst_count, locus, MIR_NULL_VALUE);
   }

   mir_build_return(mu, inst);

   vlog_lower_cleanup(&g);

   hash_free(map);

   mir_optimise(mu, MIR_PASS_O1);
   mir_put_unit(mc, mu);
}

mir_unit_t *vlog_lower_thunk(mir_context_t *mc, ident_t parent, vlog_node_t v)
{
   mir_shape_t *shape = parent != NULL ? mir_get_shape(mc, parent) : NULL;
   mir_unit_t *mu = mir_unit_new(mc, NULL, vlog_to_object(v), MIR_UNIT_THUNK,
                                 shape);

   vlog_gen_t g = {
      .mu = mu,
   };

   gen_stack_t gs = {};

   switch (vlog_kind(v)) {
   case V_FOR_INIT:
      assert(vlog_decls(v) == 0);   // TODO
      // Fall-through
   case V_FOR_STEP:
      vlog_lower_stmts(&g, v, &gs);
      mir_build_return(mu, MIR_NULL_VALUE);
      break;
   case V_LOCALPARAM:
      {
         vlog_node_t dt = vlog_type(v);
         if (is_implicit_data_type(dt) && vlog_ranges(dt) == 0) {
            // TODO: better to set null type?
            mir_value_t value = vlog_lower_rvalue(&g, vlog_value(v));

            mir_set_result(mu, mir_get_type(mu, value));
            mir_build_return(mu, value);
         }
         else {
            const type_info_t *ti = vlog_type_info(&g, dt);
            mir_value_t value = vlog_lower_with_context(&g, vlog_value(v),
                                                        ti->type);

            mir_value_t cast = vlog_lower_cast(&g, ti->type, value);

            mir_set_result(mu, ti->type);
            mir_build_return(mu, cast);
         }
      }
      break;
   default:
      {
         mir_value_t value = vlog_lower_rvalue(&g, v);
         mir_set_result(mu, mir_get_type(mu, value));
         mir_build_return(mu, value);
      }
      break;
   }

   mir_optimise(mu, MIR_PASS_O0);

   vlog_lower_cleanup(&g);
   return mu;
}

void vlog_lower_const_funcs(mir_context_t *mc, vlog_node_t inst)
{
   const int ndecls = vlog_decls(inst);
   for (int i = 0; i < ndecls; i++) {
      vlog_node_t d = vlog_decl(inst, i);
      if (vlog_kind(d) == V_FUNC_DECL && (vlog_flags(d) & VLOG_F_CONST)) {
         ident_t qual = ident_sprintf("%s.%s@const", istr(vlog_ident2(d)),
                                      istr(vlog_ident(d)));
         mir_defer(mc, qual, NULL, MIR_UNIT_FUNCTION, vlog_lower_func_decl,
                   vlog_to_object(d));
      }
   }
}
